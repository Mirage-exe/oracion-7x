import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { MobileBottomNav } from './components/MobileBottomNav';
import { LoginScreen } from './components/LoginScreen';
import { InstallGuideModal } from './components/InstallGuideModal';
import { DownloadZipModal } from './components/DownloadZipModal';
import { ConsecutivePrayerFlow } from './components/ConsecutivePrayerFlow';
import { ManuscriptViewer } from './components/ManuscriptViewer';
import { HolyWaterRitual } from './components/HolyWaterRitual';
import { DailyTracker } from './components/DailyTracker';
import { PersonalizePrayerModal } from './components/PersonalizePrayerModal';
import { MiracleJournal } from './components/MiracleJournal';
import { EmergencyModal } from './components/EmergencyModal';
import { FaqSection } from './components/FaqSection';
import { Language, UserJournalEntry } from './types';
import { sacredAudio } from './utils/audioSystem';

export default function App() {
  const [lang, setLang] = useState<Language>(() => {
    return (localStorage.getItem('capitulo_lang') as Language) || 'es';
  });

  // Login Authentication state
  const [userEmail, setUserEmail] = useState<string | null>(() => {
    return localStorage.getItem('capitulo_user_email');
  });

  const [currentTab, setCurrentTab] = useState<string>('flow');
  const [isAmbientPlaying, setIsAmbientPlaying] = useState<boolean>(false);
  const [isEmergencyOpen, setIsEmergencyOpen] = useState<boolean>(false);
  const [isInstallGuideOpen, setIsInstallGuideOpen] = useState<boolean>(false);
  const [isDownloadZipOpen, setIsDownloadZipOpen] = useState<boolean>(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  // 21 days completed tracking
  const [completedDays, setCompletedDays] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem('capitulo_completed_days');
      return saved ? JSON.parse(saved) : [1];
    } catch {
      return [1];
    }
  });

  // Streak days
  const [streakDays, setStreakDays] = useState<number>(() => {
    const saved = localStorage.getItem('capitulo_streak');
    return saved ? parseInt(saved, 10) : 3;
  });

  // Miracle Journal entries
  const [journalEntries, setJournalEntries] = useState<UserJournalEntry[]>(() => {
    try {
      const saved = localStorage.getItem('capitulo_journal_entries');
      if (saved) return JSON.parse(saved);
    } catch { /* empty */ }
    return [
      {
        id: 'initial-sample',
        date: new Date().toLocaleDateString('es-ES', { month: 'short', day: 'numeric', year: 'numeric' }),
        title: 'Comienzo de mi Consagración con los 3 Arcángeles',
        description: 'Inicio hoy mi jornada de oración con fe absoluta en la orden que el Padre Juan Bautista reveló: Rafael primero, Gabriel segundo y Miguel al final.',
        category: 'outro',
        answered: false
      }
    ];
  });

  // Capture PWA install prompt
  useEffect(() => {
    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
  }, []);

  const handleTriggerInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choiceResult = await deferredPrompt.userChoice;
      if (choiceResult.outcome === 'accepted') {
        setDeferredPrompt(null);
        setIsInstallGuideOpen(false);
      }
    }
  };

  // Save changes to localStorage
  useEffect(() => {
    localStorage.setItem('capitulo_lang', lang);
  }, [lang]);

  useEffect(() => {
    localStorage.setItem('capitulo_completed_days', JSON.stringify(completedDays));
  }, [completedDays]);

  useEffect(() => {
    localStorage.setItem('capitulo_streak', streakDays.toString());
  }, [streakDays]);

  useEffect(() => {
    localStorage.setItem('capitulo_journal_entries', JSON.stringify(journalEntries));
  }, [journalEntries]);

  const handleLoginSuccess = (email: string) => {
    localStorage.setItem('capitulo_user_email', email);
    setUserEmail(email);
    sacredAudio.playCathedralChime();
  };

  const handleLogout = () => {
    localStorage.removeItem('capitulo_user_email');
    setUserEmail(null);
  };

  // Ambient sound toggle
  const toggleAmbientSound = () => {
    if (isAmbientPlaying) {
      sacredAudio.stopSacredFrequency();
      setIsAmbientPlaying(false);
    } else {
      sacredAudio.playSacredFrequency(432, 0.06);
      setIsAmbientPlaying(true);
    }
  };

  const handleCompleteSession = () => {
    const todayNum = (completedDays.length % 21) + 1;
    if (!completedDays.includes(todayNum)) {
      setCompletedDays(prev => [...prev, todayNum]);
    }
    setStreakDays(prev => prev + 1);
  };

  const handleToggleDay = (day: number) => {
    setCompletedDays(prev => {
      if (prev.includes(day)) {
        return prev.filter(d => d !== day);
      } else {
        sacredAudio.playCathedralChime();
        return [...prev, day];
      }
    });
  };

  const handleAddJournalEntry = (newEntry: Omit<UserJournalEntry, 'id'>) => {
    const entry: UserJournalEntry = {
      ...newEntry,
      id: Date.now().toString()
    };
    setJournalEntries(prev => [entry, ...prev]);
    sacredAudio.playCathedralChime();
  };

  const handleToggleAnswered = (id: string) => {
    setJournalEntries(prev =>
      prev.map(item => (item.id === id ? { ...item, answered: !item.answered } : item))
    );
    sacredAudio.playCathedralChime();
  };

  const handleDeleteEntry = (id: string) => {
    setJournalEntries(prev => prev.filter(item => item.id !== id));
  };

  const isPt = lang === 'pt';

  // If not logged in, show Login Screen
  if (!userEmail) {
    return (
      <LoginScreen
        lang={lang}
        setLang={setLang}
        onLoginSuccess={handleLoginSuccess}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-amber-500/30 selection:text-amber-200">
      {/* Top Navbar */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        lang={lang}
        setLang={setLang}
        isAmbientPlaying={isAmbientPlaying}
        toggleAmbientSound={toggleAmbientSound}
        onOpenEmergency={() => setIsEmergencyOpen(true)}
        onOpenInstallGuide={() => setIsInstallGuideOpen(true)}
        onOpenDownloadZip={() => setIsDownloadZipOpen(true)}
        userEmail={userEmail}
        onLogout={handleLogout}
        streakDays={streakDays}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-10 space-y-8 pb-24 md:pb-12">
        {currentTab === 'flow' && (
          <ConsecutivePrayerFlow
            lang={lang}
            onCompleteSession={handleCompleteSession}
            isTodayDone={completedDays.length > 0}
          />
        )}

        {currentTab === 'manuscript' && (
          <ManuscriptViewer lang={lang} />
        )}

        {currentTab === 'holywater' && (
          <HolyWaterRitual lang={lang} />
        )}

        {currentTab === 'tracker' && (
          <DailyTracker
            lang={lang}
            streakDays={streakDays}
            completedDays={completedDays}
            onToggleDay={handleToggleDay}
            onResetStreak={() => setStreakDays(0)}
          />
        )}

        {currentTab === 'consecrate' && (
          <PersonalizePrayerModal
            lang={lang}
            onSaveToJournal={(title, description, category) => {
              handleAddJournalEntry({
                title,
                description,
                category,
                date: new Date().toLocaleDateString(isPt ? 'pt-BR' : 'es-ES', { month: 'short', day: 'numeric', year: 'numeric' }),
                answered: false
              });
              setCurrentTab('journal');
            }}
          />
        )}

        {currentTab === 'journal' && (
          <MiracleJournal
            lang={lang}
            entries={journalEntries}
            onAddEntry={handleAddJournalEntry}
            onToggleAnswered={handleToggleAnswered}
            onDeleteEntry={handleDeleteEntry}
          />
        )}

        {/* Quick Zip Download Banner in Footer Area */}
        <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/60 border border-slate-800 text-center flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-left">
            <span className="text-xs font-bold text-amber-300 block">
              {isPt ? 'Quer baixar este aplicativo para seu computador ou hospedagem?' : '¿Deseas descargar esta aplicación para tu servidor?'}
            </span>
            <span className="text-[11px] text-slate-400">
              {isPt ? 'Disponível em arquivo ZIP pronto para colocar no ar.' : 'Disponible en archivo ZIP listo para publicar.'}
            </span>
          </div>
          <button
            onClick={() => setIsDownloadZipOpen(true)}
            className="px-4 py-2 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-bold hover:bg-amber-500/30 transition-all shrink-0"
          >
            {isPt ? 'Ver Arquivos para Download (.ZIP)' : 'Ver Archivos para Descargar (.ZIP)'}
          </button>
        </div>

        {/* FAQ Section at bottom for reassurance */}
        <FaqSection lang={lang} />
      </main>

      {/* Sacred Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/90 py-6 px-4 text-center text-xs text-slate-500 pb-20 md:pb-6">
        <div className="max-w-4xl mx-auto space-y-2">
          <div className="flex items-center justify-center gap-2 text-amber-400 font-serif-sacred font-bold text-sm">
            <span>✠</span>
            <span>{isPt ? 'O Capítulo Proibido • Padre Juan Bautista' : 'El Capítulo Prohibido • Padre Juan Bautista'}</span>
            <span>✠</span>
          </div>
          <p className="text-slate-400 text-xs">
            {isPt 
              ? '«Rafael primeiro, Gabriel depois, Miguel ao final.»'
              : '«Rafael primero, Gabriel después, Miguel al final.»'}
          </p>
        </div>
      </footer>

      {/* Mobile-First Bottom Navigation Bar */}
      <MobileBottomNav
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        lang={lang}
      />

      {/* Emergency Modal */}
      <EmergencyModal
        isOpen={isEmergencyOpen}
        onClose={() => setIsEmergencyOpen(false)}
        lang={lang}
      />

      {/* Install Guide Modal */}
      <InstallGuideModal
        isOpen={isInstallGuideOpen}
        onClose={() => setIsInstallGuideOpen(false)}
        lang={lang}
        installPrompt={deferredPrompt}
        onTriggerInstall={handleTriggerInstall}
      />

      {/* Download Zip Modal */}
      <DownloadZipModal
        isOpen={isDownloadZipOpen}
        onClose={() => setIsDownloadZipOpen(false)}
        lang={lang}
      />
    </div>
  );
}
