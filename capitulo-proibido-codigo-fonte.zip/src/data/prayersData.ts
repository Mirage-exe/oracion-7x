import { PrayerSection, MiracleStory, HolyWaterStep } from '../types';

export const PRAYERS_DATA: PrayerSection[] = [
  {
    id: 'rafael',
    order: 1,
    name: 'San Rafael Arcángel',
    namePt: 'São Rafael Arcanjo',
    title: 'El Ángel de la Sanación y Limpieza Espiritual',
    titlePt: 'O Anjo da Cura e Limpeza Espiritual',
    latinName: 'Sancte Raphael, Medicina Dei',
    domain: 'Cura física, sanación de heridas invisibles, liberación de cargas y dolores',
    domainPt: 'Cura física, cura de feridas invisíveis, libertação de fardos e dores',
    quoteVsl: 'Rafael va primero. Porque si pides prosperidad con el cuerpo enfermo, no funciona. Si pides protección con el espíritu atado, no funciona.',
    quoteVslPt: 'Rafael vem primeiro. Porque se você pede prosperidade com o corpo doente, não funciona. Se pede proteção com o espírito aprisionado, não funciona.',
    symbol: 'Báculo de Sanación y Frasco de Bálsamo Divino',
    colorTheme: {
      primary: 'emerald',
      bgBadge: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30',
      textBadge: 'text-emerald-400',
      border: 'border-emerald-500/30',
      glow: 'shadow-[0_0_50px_-15px_rgba(16,185,129,0.35)]',
      accent: 'from-emerald-500 to-teal-400'
    },
    durationMin: 3,
    frequencyHz: 528,
    frequencyName: '528 Hz - Frecuencia de Reparación y Salud Celular',
    stanzas: {
      es: [
        '¡Glorioso Arcángel San Rafael, Medicina Viva de Dios! Tú que guiaste al joven Tobías y devolviste la vista a su padre, entra en este momento en mi templo interior.',
        'Extiende tus alas de luz esmeralda sobre mi cuerpo y mi espíritu. Limpia cada dolor, disuelve toda enfermedad oculta, desata los nudos de angustia y remueve el veneno de la desesperanza.',
        'Prepara el terreno sagrado de mi vida. Quita de mí toda debilidad, fatiga y herida no sanada, para que mi alma sea un altar limpio, digno de recibir los milagros del Altísimo.',
        'Por la virtud de la Santa Cruz y el mandato divino, te declaro mi médico celestial. Sano estoy, libre estoy, listo estoy para recibir la bendición. Amén.'
      ],
      pt: [
        'Glorioso Arcanjo São Rafael, Medicina Viva de Deus! Vós que guiastes o jovem Tobias e restaurastes a visão de seu pai, entrai neste momento em meu templo interior.',
        'Estendei vossas asas de luz esmeralda sobre meu corpo e meu espírito. Limpai cada dor, dissolvei toda enfermidade oculta, desatai os nós da angústia e removei o veneno do desespero.',
        'Preparai o terreno sagrado de minha vida. Tirai de mim toda fraqueza, fadiga e ferida não cicatrizada, para que minha alma seja um altar limpo, digno de receber os milagres do Altíssimo.',
        'Pela virtude da Santa Cruz e pelo mandamento divino, declaro-vos meu médico celestial. Estou curado, estou livre, estou pronto para receber a bênção. Amém.'
      ]
    },
    emergencyPrayer: {
      titleEs: 'Clamor de Emergencia a San Rafael (Salud Urgente)',
      titlePt: 'Clamor de Emergência a São Rafael (Saúde Urgente)',
      textEs: '¡San Rafael, bálsamo de Dios, desciende ahora mismo! Toca mi cuerpo, expulsa este dolor, aplaca la fiebre, calma el corazón y restaura mi salud en este instante sagrado. Amén.',
      textPt: 'São Rafael, bálsamo de Deus, descei agora mesmo! Tocai meu corpo, expulsai esta dor, acalmai o coração e restaurai minha saúde neste instante sagrado. Amém.'
    }
  },
  {
    id: 'gabriel',
    order: 2,
    name: 'San Gabriel Arcángel',
    namePt: 'São Gabriel Arcanjo',
    title: 'El Ángel de la Anunciación y la Apertura de Caminos',
    titlePt: 'O Anjo da Anunciação e Abertura de Caminhos',
    latinName: 'Sancte Gabriel, Fortitudo Dei',
    domain: 'Prosperidade, provisão inesperada, boas notícias, fim de dívidas e portas abertas',
    domainPt: 'Prosperidade, provisão inesperada, boas notícias, fim de dívidas e portas abertas',
    quoteVsl: 'Gabriel va segundo. Cuando el cuerpo está sano y el espíritu en paz, llega Gabriel, abre las puertas cerradas y anuncia las oportunidades de bendición y provisión.',
    quoteVslPt: 'Gabriel vem em segundo. Quando o corpo está são e o espírito em paz, chega Gabriel, abre as portas trancadas e anuncia as oportunidades de bênção e provisão.',
    symbol: 'Trompeta de Victoria y Lirio de la Pureza',
    colorTheme: {
      primary: 'amber',
      bgBadge: 'bg-amber-500/10 text-amber-300 border-amber-500/30',
      textBadge: 'text-amber-400',
      border: 'border-amber-500/30',
      glow: 'shadow-[0_0_50px_-15px_rgba(245,158,11,0.35)]',
      accent: 'from-amber-400 to-yellow-300'
    },
    durationMin: 3,
    frequencyHz: 432,
    frequencyName: '432 Hz - Frecuencia de Claridad, Armonía y Abundancia Divina',
    stanzas: {
      es: [
        '¡Soberano Arcángel San Gabriel, Mensajero de las Buenas Nuevas y Fortaleza del Altísimo! Tú que anunciaste la encarnación del Salvador a la Virgen María, escucha mi voz en este amanecer.',
        'Ahora que mi cuerpo y alma han sido purificados por Rafael, te convoco para abrir las puertas de mi destino. Desbloquea los caminos financieros, disuelve las deudas que me oprimen y trae hacia mí la provisión justa y abundante.',
        'Haz sonar tu trompeta celestial derribando los muros de escasez. Que lleguen noticias bendecidas de trabajo, negocios, ventas y prosperidad honesta a mi mesa y a mi familia.',
        'Declaro que donde había puertas de bronce cerradas, Dios las hace añicos con tu voz. Recibo la noticia de mi milagro económico hoy mismo. Amén.'
      ],
      pt: [
        'Soberano Arcanjo São Gabriel, Mensageiro das Boas Novas e Fortaleza do Altíssimo! Vós que anunciastes a encarnação do Salvador à Virgem Maria, ouvi minha voz neste momento.',
        'Agora que meu corpo e minha alma foram purificados por Rafael, convoco-vos para abrir as portas de meu destino. Desbloqueai os caminhos financeiros, dissolvei as dívidas que me oprimem e trazei a mim a provisão justa e abundante.',
        'Fazei soar vossa trombeta celestial derrubando os muros da escassez. Que cheguem notícias abençoadas de trabalho, negócios, vendas e prosperidade honesta à minha mesa e à minha família.',
        'Declaro que onde havia portas trancadas, Deus as quebra com vossa voz. Recebo a notícia do meu milagre econômico hoje mesmo. Amém.'
      ]
    },
    emergencyPrayer: {
      titleEs: 'Clamor de Emergencia a San Gabriel (Auxilio Financiero Inmediato)',
      titlePt: 'Clamor de Emergência a São Gabriel (Auxílio Financeiro Imediato)',
      textEs: '¡San Gabriel Arcángel, portador de las grandes noticias! No tengo de dónde pagar, las puertas parecen cerradas. ¡Abre un camino donde no lo hay, envía socorro y recursos providenciales hoy! Amén.',
      textPt: 'São Gabriel Arcanjo, portador das grandes notícias! Não sei como pagar, as portas parecem fechadas. Abri um caminho onde não há, enviai socorro e recursos providenciais hoje! Amém.'
    }
  },
  {
    id: 'miguel',
    order: 3,
    name: 'San Miguel Arcángel',
    namePt: 'São Miguel Arcanjo',
    title: 'El Ángel Guerrero y Escudo Protector',
    titlePt: 'O Anjo Guerreiro e Escudo Protetor',
    latinName: 'Sancte Michael Archangele, Defensor Noster',
    domain: 'Proteção contra o mal, quebra de inveja, blindagem do lar e selo de bênçãos',
    domainPt: 'Proteção contra o mal, quebra de inveja, blindagem do lar e selo de bênçãos',
    quoteVsl: 'Miguel va al final. Porque después de sanar y recibir la provisión, Miguel llega a cubrirte la espalda, protegiendo lo recibido para que nadie te robe el milagro.',
    quoteVslPt: 'Miguel vem ao final. Porque após curar e receber a provisão, Miguel chega para cobrir suas costas, protegendo o que foi recebido para que ninguém roube seu milagre.',
    symbol: 'Espada de Fuego Azul y Balanza de la Justicia Divina',
    colorTheme: {
      primary: 'blue',
      bgBadge: 'bg-blue-500/10 text-blue-300 border-blue-500/30',
      textBadge: 'text-blue-400',
      border: 'border-blue-500/30',
      glow: 'shadow-[0_0_50px_-15px_rgba(59,130,246,0.35)]',
      accent: 'from-blue-500 to-indigo-400'
    },
    durationMin: 3,
    frequencyHz: 741,
    frequencyName: '741 Hz - Frecuencia de Despertar Intuitivo y Blindaje Espiritual',
    stanzas: {
      es: [
        '¡Invencible San Miguel Arcángel, Príncipe de la Milicia Celestial y Guardián del Trono de Dios! Defiéndenos en la batalla, sé nuestro amparo contra la perversidad y asechanzas del maligno.',
        'Desenvaina tu espada de fuego azul celestial y colócate a la puerta de mi hogar. Corta toda envidia, malos ojos, maleficios, celos y energías de discordia que hayan querido perturbar mi paz o a mis hijos.',
        'Sella con tu escudo inexpugnable todo lo que Dios me ha entregado por medio de Rafael y Gabriel. Que ninguna mano usurpadora ni oscuridad robe mi bendición económica ni la salud restablecida de mi familia.',
        '¿Quién como Dios? ¡Nadie como Dios! Quedo bajo tu manto de protección impenetrable día y noche. Amén.'
      ],
      pt: [
        'Invencível São Miguel Arcanjo, Príncipe da Milícia Celeste e Guardião do Trono de Deus! Defendei-nos no combate, sede nosso refúgio contra as ciladas e maldades do inimigo.',
        'Desembainhai vossa espada de fogo azul celeste e colocai-vos à porta de meu lar. Cortai toda inveja, mau-olhado, discórdias e energias pesadas que quiseram perturbar minha paz e meus filhos.',
        'Selai com vosso escudo impenetrável tudo o que Deus me entregou por meio de Rafael e Gabriel. Que nenhuma mão ladra ou treva roube minha bênção financeira nem a saúde restabelecida de minha família.',
        'Quem como Deus? Ninguém como Deus! Fico sob vosso manto de proteção impenetrável dia e noite. Amém.'
      ]
    },
    emergencyPrayer: {
      titleEs: 'Clamor de Emergencia a San Miguel (Protección y Corte de Mal)',
      titlePt: 'Clamor de Emergência a São Miguel (Proteção e Corte do Mal)',
      textEs: '¡San Miguel Arcángel, con tu espada de fuego azul ven en mi defensa! Aleja el peligro, desarma la mala intención, corta las cadenas de pesadillas y angustia, y blinda mi hogar ahora. ¡Amén!',
      textPt: 'São Miguel Arcanjo, com vossa espada de fogo azul vinde em minha defesa! Afastai o perigo, desatai a má intenção, cortai as correntes de pesadelos e angústias, e blindai meu lar agora. Amém!'
    }
  }
];

export const TESTIMONIALS_DATA: MiracleStory[] = [
  {
    id: 'lourdes-cordoba',
    name: 'Lourdes M.',
    location: 'Córdoba, Argentina',
    archangel: 'gabriel',
    tag: 'Finanzas & Familia',
    storyEs: 'Estaba ahogada en deudas, sin dinero ni para pagar el alquiler a fin de mes. Empecé a seguir la orden del Padre Juan Bautista todos los días temprano en la cocina escuchando el audio. Al tercer día recibí un encargo grande e inesperado de tortas, y luego otro más. Pude salir del buró de crédito, comprarme un teléfono nuevo y todavía me sobró dinero. Además, mi esposo que era muy enojón y no pisaba la iglesia se volvió cariñoso y ahora me acompaña todos los domingos.',
    storyPt: 'Estava afundada em dívidas, sem dinheiro nem para o aluguel no fim do mês. Comecei a seguir a ordem do Padre Juan Bautista todos os dias cedinho na cozinha ouvindo o áudio. No terceiro dia recebi uma encomenda grande e inesperada de bolos, e depois outra. Consegui limpar meu nome, comprei um celular novo e ainda sobrou dinheiro. Além disso, meu marido, que era muito irritado e não pisava na igreja, ficou carinhoso e agora me acompanha todos os domingos.',
    quoteEs: '¡Pude pagar todas mis deudas en cuestión de semanas y me sobró dinero!',
    quotePt: 'Pude pagar todas as minhas dívidas em semanas e ainda sobrou dinheiro!',
    verifiedBadge: true
  },
  {
    id: 'marina-pulmones',
    name: 'Marina S.',
    age: 67,
    location: 'Rosario, Argentina',
    archangel: 'rafael',
    tag: 'Salud & Cura Milagrosa',
    storyEs: 'Los médicos me habían desahuciado por un cuadro pulmonar muy grave y no teníamos recursos para costear los tratamientos caros. Mi hija me consiguió las oraciones y recé la oración de Rafael durante 35 días seguidos, sin fallar uno solo, sintiendo un calor en el pecho. Cuando volví a la clínica para nuevos estudios, los doctores no podían creerlo: ¡mis pulmones estaban limpios, la enfermedad había desaparecido por completo!',
    storyPt: 'Os médicos haviam me desenganado por um problema pulmonar gravíssimo e não tínhamos recursos para tratamentos caros. Minha filha conseguiu as orações e rezei a oração de Rafael durante 35 dias seguidos, sem falhar nenhum, sentindo um calor no peito. Quando voltei à clínica para novos exames, os médicos não acreditaram: meus pulmões estavam limpos, a doença havia sumido completamente!',
    quoteEs: '¡35 días de oración ininterrumpida y los médicos no encontraron rastro alguno de la enfermedad!',
    quotePt: '35 dias de oração ininterrupta e os médicos não encontraram nenhum vestígio da doença!',
    verifiedBadge: true
  },
  {
    id: 'carlos-guardia',
    name: 'Carlos V.',
    location: 'Mendoza, Argentina',
    archangel: 'miguel',
    tag: 'Protección Física & Paz del Hogar',
    storyEs: 'Trabajo como guardia de seguridad nocturno. En mi casa se sentía un ambiente pesado: mi esposa pasaba noches enteras sin dormir y mi hijo pequeño se despertaba llorando con pesadillas aterradoras. Al empezar la invocación a San Miguel antes de salir y al volver a casa, la primera semana la paz retornó. Y lo más impactante: durante un intento de robo armado en mi turno de guardia, quedé en la línea de fuego y una bala me rozó apenas la oreja sin lastimarme. San Miguel cubrió mi espalda tal como prometió el Padre Juan Bautista.',
    storyPt: 'Trabalho como segurança noturno. Em casa o clima era pesado: minha esposa não dormia e meu filho acordava chorando com pesadelos horríveis. Ao começar a invocação a São Miguel antes de sair e ao voltar, na primeira semana a paz voltou. E o mais marcante: em um assalto armado no meu turno, fiquei na linha de tiro e uma bala raspou na minha orelha sem me ferir. São Miguel cobriu minhas costas como prometido pelo Padre Juan Bautista.',
    quoteEs: '¡La bala rozó mi oreja en un asalto y no me tocó! Mi hogar hoy respira paz total.',
    quotePt: 'A bala raspou na minha orelha em um assalto e não me atingiu! Minha casa hoje vive em paz.',
    verifiedBadge: true
  }
];

export const HOLY_WATER_STEPS: HolyWaterStep[] = [
  {
    step: 1,
    titleEs: 'El Vaso de Cristal y el Agua Pura',
    titlePt: 'O Copo de Cristal e a Água Pura',
    instructionEs: 'Toma un vaso de vidrio transparente sin marcas ni roturas. Llénalo con agua potable fresca y limpia. Colócalo sobre una mesa con un paño limpio antes del amanecer o al anochecer.',
    instructionPt: 'Pegue um copo de vidro transparente sem trincas. Encha-o com água potável limpa e fresca. Coloque-o sobre uma mesa com uma toalha limpa antes do amanhecer ou ao anoitecer.',
    archangelNoteEs: 'El agua representa la receptividad pura del alma ante las frecuencias divinas.',
    archangelNotePt: 'A água representa a receptividade pura da alma diante das frequências divinas.',
    invocationEs: 'En el nombre del Padre, del Hijo y del Espíritu Santo. Que esta agua sea santificada para purificar mi vida y mi morada.',
    invocationPt: 'Em nome do Pai, do Filho e do Espírito Santo. Que esta água seja santificada para purificar minha vida e minha morada.'
  },
  {
    step: 2,
    titleEs: 'La Primera Activación: San Rafael (Purificación)',
    titlePt: 'A Primeira Ativação: São Rafael (Purificação)',
    instructionEs: 'Coloca tu mano derecha sobre el vaso sin tocar el agua. Reza la Oración de San Rafael visualizando un rayo de luz verde esmeralda impregnando cada gota.',
    instructionPt: 'Coloque sua mão direita sobre o copo sem tocar na água. Reze a Oração de São Rafael visualizando um raio de luz verde esmeralda penetrando cada gota.',
    archangelNoteEs: 'Rafael convierte el agua en medicina viva que limpia el ambiente de cargas de enfermedad y pesadez.',
    archangelNotePt: 'Rafael transforma a água em remédio vivo que limpa o ambiente de fardos de enfermidade e peso.',
    invocationEs: '¡San Rafael Arcángel, infunde tu bálsamo celeste en esta agua para sanar cuerpo, mente y morada!',
    invocationPt: 'São Rafael Arcanjo, infundi vosso bálsamo celeste nesta água para curar corpo, mente e morada!'
  },
  {
    step: 3,
    titleEs: 'La Segunda Activación: San Gabriel (Magnetismo de Abundancia)',
    titlePt: 'A Segunda Ativação: São Gabriel (Magnetismo de Abundância)',
    instructionEs: 'Mantén ambas manos abiertas a los lados del vaso. Reza la Oración de San Gabriel, proyectando bendiciones doradas sobre tus proyectos, billetera y despensa.',
    instructionPt: 'Mantenha as duas mãos abertas aos lados do copo. Reze a Oração de São Gabriel, projetando bênçãos douradas sobre seus projetos, carteira e despensa.',
    archangelNoteEs: 'Gabriel imanta el agua con la frecuencia de las buenas noticias y la provisión inesperada.',
    archangelNotePt: 'Gabriel imanta a água com a frequência das boas notícias e da provisão inesperada.',
    invocationEs: '¡San Gabriel Arcángel, haz sonar tu trompeta de gracia sobre esta agua y abre los caminos de mi prosperidad!',
    invocationPt: 'São Gabriel Arcanjo, fazei soar vossa trombeta de graça sobre esta água e abri os caminhos da minha prosperidade!'
  },
  {
    step: 4,
    titleEs: 'La Tercera Activación: San Miguel (Blindaje y Sellado)',
    titlePt: 'A Terceira Ativação: São Miguel (Blindagem e Selamento)',
    instructionEs: 'Haz la señal de la cruz tres veces sobre el vaso. Reza la Oración de San Miguel pidiendo que su fuego azul corte todo mal y selle las bendiciones.',
    instructionPt: 'Faça o sinal da cruz três vezes sobre o copo. Reze a Oração de São Miguel pedindo que seu fogo azul corte todo o mal e sele as bênçãos.',
    archangelNoteEs: 'Bebe tres sorbos con fe profunda y con las gotas restantes rocía suavemente las esquinas de tu casa o negocio.',
    archangelNotePt: 'Beba três goles com fé profunda e com as gotas restantes borrife suavemente os cantos da sua casa ou trabalho.',
    invocationEs: '¡San Miguel Arcángel, sella este hogar y mi vida. Que ningún mal se acerque a esta tienda sagrada. Amén!',
    invocationPt: 'São Miguel Arcanjo, selai este lar e minha vida. Que nenhum mal se aproxime desta tenda sagrada. Amém!'
  }
];

export const VATICAN_MANUSCRIPT_PROLOGUE = {
  latin: `IN NOMINE SANCTISSIMAE TRINITATIS ET ORDINIS ANGELORUM.
Capitulum Secretum de Tribus Ministris Divinae Misericordiae.
Cavete ne ordinem sanctum perturbetis:
Primo Raphael ad purificandum et sanandum;
Deinde Gabriel ad aperiendum portas et nuntiandum;
Postremo Michael ad custodiendum et profligandum inimicum.
Quicumque hoc ordine oraverit, portas caeli apertas inveniet.`,
  translationEs: `EN EL NOMBRE DE LA SANTÍSIMA TRINIDAD Y DEL ORDEN DE LOS ÁNGELES.
Capítulo Secreto de los Tres Ministros de la Misericordia Divina.
Guardaos de perturbar el orden sagrado:
Primero Rafael para purificar y sanar;
Luego Gabriel para abrir puertas y anunciar;
Finalmente Miguel para custodiar y desbaratar al enemigo.
Quienquiera que rece en este orden, hallará las puertas del cielo abiertas de par en par.`,
  translationPt: `EM NOME DA SANTÍSSIMA TRINDADE E DA ORDEM DOS ANJOS.
Capítulo Secreto dos Três Ministros da Misericórdia Divina.
Guardai-vos de perturbar a ordem sagrada:
Primeiro Rafael para purificar e curar;
Depois Gabriel para abrir portas e anunciar;
Por fim Miguel para guardar e derrotar o inimigo.
Quem quer que ore nesta ordem, encontrará as portas do céu abertas de par em par.`
};

export const FAQ_DATA = [
  {
    qEs: '¿Por qué rezaba antes y no veía milagros en mi vida?',
    qPt: 'Por que eu rezava antes e não via milagres acontecerem?',
    aEs: 'Como explicó el Padre Juan Bautista en la revelación, no es que Dios no te ame. Es que 99% de las personas rezan al revés: piden dinero o protección cuando el cuerpo y el alma están todavía heridos o impuros. Cuando rezas primero a Rafael (sanación), luego a Gabriel (apertura) y finalmente a Miguel (protección), el ejército celestial se alinea a tu favor.',
    aPt: 'Como explicou o Padre Juan Bautista, não é que Deus não te ame. O problema é que 99% das pessoas rezam ao contrário: pedem dinheiro ou proteção com o corpo e a alma ainda doentes ou pesados. Quando você reza primeiro a Rafael (cura), depois a Gabriel (abertura) e por fim a Miguel (proteção), o exército celestial se alinha a seu favor.'
  },
  {
    qEs: '¿A qué hora debo rezar las tres oraciones?',
    qPt: 'A que horas devo rezar as três orações?',
    aEs: 'Los dos momentos más poderosos recomendados por el Padre Juan Bautista son: 1) Al amanecer, temprano antes de salir a trabajar (como hacía Lourdes en su cocina), y 2) Al anochecer antes de dormir (como hacía Carlos para blindar su hogar).',
    aPt: 'Os dois momentos mais poderosos recomendados pelo Padre Juan Bautista são: 1) Ao amanhecer, cedinho antes de sair para o trabalho (como fazia Lourdes na cozinha), e 2) Ao anoitecer antes de dormir (como fazia Carlos para blindar a casa).'
  },
  {
    qEs: '¿Qué son las 3 Garantías del Padre Juan Bautista?',
    qPt: 'Quais são as 3 Garantias do Padre Juan Bautista?',
    aEs: 'Garantía 1: Confirmación de paz y señal en 24 Horas. Garantía 2: Transformación tangible en salud, finanzas o familia en 90 Días. Garantía 3: Multiplicación de provisión en 180 Días con el compromiso pastoral.',
    aPt: 'Garantia 1: Confirmação de paz e sinal nas primeiras 24 Horas. Garantia 2: Transformação tangível em saúde, finanças ou família em 90 Dias. Garantia 3: Multiplicação da provisão em 180 Dias.'
  }
];
