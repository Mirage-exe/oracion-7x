import { ConsecrationResult, Language } from '../types';

export function generateAutonomousConsecration(
  devoteeName: string,
  intention: string,
  category: 'saude' | 'financas' | 'familia' | 'protecao',
  lang: Language
): ConsecrationResult {
  const name = devoteeName.trim() || (lang === 'pt' ? 'Devoto de Fé' : 'Devoto de Fe');
  const intent = intention.trim();
  const isPt = lang === 'pt';

  if (isPt) {
    if (category === 'saude') {
      return {
        devoteeName: name,
        intention: intent,
        prayerRafael: `Glorioso São Rafael, Medicina Divina do Senhor, coloco aos vossos pés a vida de ${name} e esta aflição: "${intent}". Entrai com vossa luz verde esmeralda no mais profundo de suas células, órgãos e pensamentos. Removei as raízes invisíveis da dor, curai o corpo, renovai a vitalidade e dissipai todo desânimo. O corpo de ${name} agora é um templo sagrado, curado e limpo diante de Deus. Amém.`,
        prayerGabriel: `São Gabriel Arcanjo, fortaleza de Deus e mensageiro da boa nova, agora que o templo de ${name} foi purificado, abri os caminhos para a restauração completa. Que cheguem boas notícias nos exames, que os tratamentos prosperem e que a paz celestial reine sobre ${name} com vigor e alegria renovada. Amém.`,
        prayerMiguel: `Invencível São Miguel Arcanjo, desembainhai vossa espada de fogo azul celeste e colocai vosso escudo impenetrável em volta da saúde de ${name}. Que nenhuma recaída, temor ou palavra de enfermidade toque a vida deste servo de Deus. O que o Senhor curou através de Rafael, ninguém arrebatará! Amém.`,
        biblicalPromise: '«Pois eu restaurarei a tua saúde e curarei as tuas feridas, diz o Senhor.» (Jeremias 30:17)',
        divineDecree: 'Eu recebo a cura viva de Rafael, a paz de Gabriel e o escudo protetor de Miguel. Minha saúde está restaurada e selada em nome de Deus!'
      };
    }

    if (category === 'financas') {
      return {
        devoteeName: name,
        intention: intent,
        prayerRafael: `Arcanjo São Rafael, médico divino, antes de clamar pela abundância, peço que cureis o coração e o espírito de ${name} de todo desespero, ansiedade financeira e noites sem dormir causadas por: "${intent}". Limpai a mente de escassez e renovai a fé inabalável nas provisões de Deus. Amém.`,
        prayerGabriel: `Soberano São Gabriel Arcanjo, mensageiro das grandes promessas, com vossa trombeta celestial tocai agora mesmo e derrubai os muros de dívidas e escassez diante de ${name}. Abri portas de trabalho, pedidos inesperados, novos negócios e recursos para saldar toda pendência: "${intent}". Que a mesa de ${name} seja farta e sobre para abençoar outros! Amém.`,
        prayerMiguel: `São Miguel Arcanjo, príncipe dos exércitos celestes, levantai vosso escudo de bronze e fogo sobre as finanças e o patrimônio de ${name}. Cortai todo mau-olhado, inveja do trabalho e laços de perda financeira. A bênção entregue por Gabriel fica selada e protegida para sempre! Amém.`,
        biblicalPromise: '«O meu Deus suprirá todas as vossas necessidades segundo as suas gloriosas riquezas em Cristo Jesus.» (Filipenses 4:19)',
        divineDecree: 'Minhas dívidas caem por terra hoje. As portas de Gabriel estão abertas e a provisão divina chega à minha casa com poder e honra!'
      };
    }

    if (category === 'familia') {
      return {
        devoteeName: name,
        intention: intent,
        prayerRafael: `São Rafael Bendito, entrai agora na casa de ${name} e derramai vosso bálsamo sobre as feridas emocionais, mágoas e desentendimentos: "${intent}". Curai os corações endurecidos, devolvei a doçura e a mansidão às palavras entre os familiares. Amém.`,
        prayerGabriel: `São Gabriel Arcanjo, mensageiro do amor do Altíssimo, anunciai um novo tempo de concórdia, diálogo e carinho na família de ${name}. Trazei a boa nova da reconciliação, da união entre pais e filhos, e do amor restaurado no casamento. Amém.`,
        prayerMiguel: `São Miguel Arcanjo, protetor das famílias fiéis, postai-vos à soleira da porta de ${name}. Cortai todas as brigas provocadas pela inveja externa, dissipai pesadelos e energias pesadas, e blindai o lar sob vosso manto impenetrável de luz! Amém.`,
        biblicalPromise: '«Quanto a mim e à minha casa, serviremos ao Senhor.» (Josué 24:15)',
        divineDecree: 'A paz divina foi restabelecida no meu lar. O amor reina, as brigas cessaram e minha família está guardada pelos Três Arcanjos!'
      };
    }

    // Default: Proteção
    return {
      devoteeName: name,
      intention: intent,
      prayerRafael: `São Rafael Arcânjo, limpador celestial, purificai os pensamentos de ${name} de todo medo, pânico e opressão noturna relacionados a: "${intent}". Curai o espírito ferido e devolvei o sono tranquilo e a respiração serena. Amém.`,
      prayerGabriel: `São Gabriel Arcânjo, fortalecei a fé e a clareza de ${name}. Que a luz da verdade divina ilumine os passos desta alma, mostrando o caminho seguro e dissipando toda dúvida ou armadilha oculta. Amém.`,
      prayerMiguel: `Gloriosíssimo São Miguel Arcanjo, com vossa espada fulgurante em chamas celestes, tomai a frente de ${name}! Cortai invejas, malefícios, fofocas destruidoras e todo perigo visível e invisível. Quem como Deus? Ninguém como Deus! ${name} está invulnerável sob vossa guarda perpétua. Amém.`,
      biblicalPromise: '«Mil cairão ao teu lado, e dez mil à tua direita, mas tu não serás atingido.» (Salmo 91:7)',
      divineDecree: 'Nenhum mal me tocará! Eu caminho seguro, revestido com a armadura celestial de São Miguel e protegido pela santíssima ordem dos Arcanjos!'
    };
  }

  // Spanish Version
  if (category === 'saude') {
    return {
      devoteeName: name,
      intention: intent,
      prayerRafael: `Glorioso San Rafael, Medicina de Dios, pongo a tus pies la vida de ${name} y esta aflicción: "${intent}". Entra con tu rayo esmeralda sanador en lo más profundo de sus órganos y pensamientos. Remueve la raíz del dolor, restaura la energía vital y expulsa toda dolencia. El cuerpo de ${name} es un templo limpio y sano ante el Altísimo. Amén.`,
      prayerGabriel: `San Gabriel Arcángel, fortaleza de Dios, ahora que el templo de ${name} fue purificado, abre los caminos de la completa recuperación. Que lleguen noticias bendecidas de los médicos, que los tratamientos florezcan y que la alegría divina inunde a ${name}. Amén.`,
      prayerMiguel: `San Miguel Arcángel, desenvaina tu espada de fuego azul y levanta tu escudo impenetrable alrededor de la salud de ${name}. Que ningún dolor regrese y ninguna sombra robe la bendición entregada. ¡Lo que Dios sanó por Rafael, nadie lo dañará! Amén.`,
      biblicalPromise: '«Mas yo haré venir sanidad para ti, y sanaré tus heridas, dice Jehová.» (Jeremías 30:17)',
      divineDecree: '¡Recibo la sanación viva de Rafael, la paz de Gabriel y el escudo invencible de Miguel. Mi salud está restaurada en el Nombre Santo de Dios!'
    };
  }

  if (category === 'financas') {
    return {
      devoteeName: name,
      intention: intent,
      prayerRafael: `Arcángel San Rafael, antes de pedir la provisión, cura el corazón y la mente de ${name} de toda angustia por deudas y falta de recursos: "${intent}". Limpia la mente de escasez y restaura la calma para tomar decisiones sabias. Amén.`,
      prayerGabriel: `Soberano San Gabriel Arcángel, con tu trompeta celestial derriba las murallas de atrasos económicos para ${name}. Abre las puertas de nuevos clientes, pedidos inesperados, pagos justos y provisión abundante para cancelar: "${intent}". ¡Que sobre dinero a fin de mes con bendición! Amén.`,
      prayerMiguel: `San Miguel Arcángel, coloca tu escudo protector sobre el trabajo y los ingresos de ${name}. Corta toda envidia laboral y trampas de pérdida. ¡La provisión que Gabriel entregó queda blindada para siempre! Amén.`,
      biblicalPromise: '«Mi Dios, pues, suplirá todo lo que os falta conforme a sus riquezas en gloria en Cristo Jesús.» (Filipenses 4:19)',
      divineDecree: '¡Mis deudas caen hoy. Las puertas de la provisión están abiertas y la prosperidad divina fluye hacia mi hogar sin obstáculos!'
    };
  }

  if (category === 'familia') {
    return {
      devoteeName: name,
      intention: intent,
      prayerRafael: `San Rafael Bendito, entra en el hogar de ${name} y aplica tu bálsamo sobre las heridas emocionales, resentimientos y discusiones: "${intent}". Sana los corazones heridos y devuelve la dulzura al trato diario. Amén.`,
      prayerGabriel: `San Gabriel Arcángel, anuncia un nuevo tiempo de paz, cariño y respeto en la familia de ${name}. Trae la bendición de la unidad entre esposos y la rectitud para los hijos. Amén.`,
      prayerMiguel: `San Miguel Arcángel, ponte en la puerta de la casa de ${name}. Disipa las malas influencias, las pesadillas y las malas energías, y sella el hogar con tu paz celestial inviolable. Amén.`,
      biblicalPromise: '«Yo y mi casa serviremos a Jehová.» (Josué 24:15)',
      divineDecree: '¡La paz de Dios reina en mi familia. Las discordias se marchan y los Tres Arcángeles protegen nuestro techo noche y día!'
    };
  }

  // Default: Proteccion
  return {
    devoteeName: name,
    intention: intent,
    prayerRafael: `San Rafael Arcángel, purifica los pensamientos de ${name} de todo temor, pánico o zozobra en relación a: "${intent}". Devuelve el sosiego y el descanso sereno. Amén.`,
    prayerGabriel: `San Gabriel Arcángel, ilumina los pasos de ${name} con la luz de la verdad divina, despejando dudas y revelando la senda de rectitud y bienaventuranza. Amén.`,
    prayerMiguel: `San Miguel Arcángel, con tu espada fulgurante ponte al frente de ${name}. Corta envidias, malas intenciones y peligros. ¿Quién como Dios? ¡Nadie como Dios! ${name} queda bajo tu custodia sagrada. Amén.`,
    biblicalPromise: '«Caerán a tu lado mil, y diez mil a tu diestra; mas a ti no llegará.» (Salmo 91:7)',
    divineDecree: '¡Ningún mal se acercará a mi tienda! Camino confiado bajo la armadura de San Miguel y la sagrada orden de los Arcángeles!'
  };
}
