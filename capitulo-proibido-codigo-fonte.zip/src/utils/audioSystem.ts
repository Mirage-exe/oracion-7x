// Web Audio API sacred frequency generator and speech synthesis coordinator

class SacredAudioEngine {
  private ctx: AudioContext | null = null;
  private currentOsc: OscillatorNode | null = null;
  private currentGain: GainNode | null = null;
  private isTonePlaying = false;
  private currentFrequency = 432;

  private initCtx() {
    if (!this.ctx) {
      const AudioCtxClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtxClass();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  // Play a soft sacred solfeggio ambient drone
  public playSacredFrequency(hz: number, volume: number = 0.08) {
    try {
      this.initCtx();
      if (!this.ctx) return;

      this.stopSacredFrequency();

      this.currentFrequency = hz;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      // Soft lowpass filter to make it heavenly and warm, not harsh
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(hz * 1.8, this.ctx.currentTime);

      osc.type = 'sine';
      osc.frequency.setValueAtTime(hz, this.ctx.currentTime);

      // Gentle fade in
      gain.gain.setValueAtTime(0, this.ctx.currentTime);
      gain.gain.linearRampToValueAtTime(volume, this.ctx.currentTime + 1.5);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      this.currentOsc = osc;
      this.currentGain = gain;
      this.isTonePlaying = true;
    } catch (e) {
      console.warn('Audio tone error', e);
    }
  }

  public stopSacredFrequency() {
    if (this.currentGain && this.ctx) {
      try {
        this.currentGain.gain.linearRampToValueAtTime(0.0001, this.ctx.currentTime + 0.8);
        setTimeout(() => {
          if (this.currentOsc) {
            try { this.currentOsc.stop(); } catch { /* ignore */ }
            this.currentOsc.disconnect();
            this.currentOsc = null;
          }
        }, 850);
      } catch {
        if (this.currentOsc) {
          try { this.currentOsc.stop(); } catch { /* ignore */ }
          this.currentOsc = null;
        }
      }
    }
    this.isTonePlaying = false;
  }

  // Play a rich church/cathedral bell chime
  public playCathedralChime() {
    try {
      this.initCtx();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      // Multi-harmonic chime (fund, overtone 1, overtone 2)
      const freqs = [330, 660, 990];
      freqs.forEach((freq, idx) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now);

        const peakGain = 0.12 / (idx + 1);
        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(peakGain, now + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 3.5 + idx * 0.5);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(now);
        osc.stop(now + 4.5);
      });
    } catch (e) {
      console.warn('Chime error', e);
    }
  }

  public getIsPlaying(): boolean {
    return this.isTonePlaying;
  }
}

export const sacredAudio = new SacredAudioEngine();

// Speech synthesis wrapper for guided narration
export interface SpeechControllerOptions {
  text: string;
  lang: 'es' | 'pt';
  onStart?: () => void;
  onEnd?: () => void;
  onBoundary?: (charIndex: number) => void;
}

export class SacredSpeechNarrator {
  private utterance: SpeechSynthesisUtterance | null = null;
  private isSpeaking = false;

  public speak(options: SpeechControllerOptions) {
    if (!('speechSynthesis' in window)) {
      options.onStart?.();
      setTimeout(() => options.onEnd?.(), 4000);
      return;
    }

    this.stop();

    const utterance = new SpeechSynthesisUtterance(options.text);
    utterance.lang = options.lang === 'pt' ? 'pt-BR' : 'es-ES';
    utterance.rate = 0.88; // Reverent, solemn, deliberate cadence
    utterance.pitch = 0.95; // Calm and grounded

    // Try to find a solemn/natural sounding voice
    const voices = window.speechSynthesis.getVoices();
    const prefix = options.lang === 'pt' ? 'pt' : 'es';
    const preferredVoice = voices.find(v => v.lang.startsWith(prefix) && (v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('Male')));
    if (preferredVoice) {
      utterance.voice = preferredVoice;
    }

    utterance.onstart = () => {
      this.isSpeaking = true;
      options.onStart?.();
    };

    utterance.onend = () => {
      this.isSpeaking = false;
      options.onEnd?.();
    };

    utterance.onerror = () => {
      this.isSpeaking = false;
      options.onEnd?.();
    };

    this.utterance = utterance;
    window.speechSynthesis.speak(utterance);
  }

  public pause() {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.pause();
    }
  }

  public resume() {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.resume();
    }
  }

  public stop() {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    this.isSpeaking = false;
  }

  public getSpeaking(): boolean {
    return this.isSpeaking;
  }
}

export const speechNarrator = new SacredSpeechNarrator();
