export type Language = 'es' | 'pt';

export type ArchangelId = 'rafael' | 'gabriel' | 'miguel';

export interface PrayerSection {
  id: ArchangelId;
  order: 1 | 2 | 3;
  name: string;
  namePt: string;
  title: string;
  titlePt: string;
  latinName: string;
  domain: string;
  domainPt: string;
  quoteVsl: string;
  quoteVslPt: string;
  symbol: string;
  colorTheme: {
    primary: string;
    bgBadge: string;
    textBadge: string;
    border: string;
    glow: string;
    accent: string;
  };
  durationMin: number;
  frequencyHz: number;
  frequencyName: string;
  stanzas: {
    es: string[];
    pt: string[];
  };
  emergencyPrayer: {
    titleEs: string;
    titlePt: string;
    textEs: string;
    textPt: string;
  };
}

export interface MiracleStory {
  id: string;
  name: string;
  location: string;
  age?: number;
  archangel: ArchangelId;
  tag: string;
  storyEs: string;
  storyPt: string;
  quoteEs: string;
  quotePt: string;
  verifiedBadge: boolean;
}

export interface HolyWaterStep {
  step: number;
  titleEs: string;
  titlePt: string;
  instructionEs: string;
  instructionPt: string;
  archangelNoteEs: string;
  archangelNotePt: string;
  invocationEs: string;
  invocationPt: string;
}

export interface UserJournalEntry {
  id: string;
  date: string;
  title: string;
  description: string;
  category: 'saude' | 'financas' | 'familia' | 'protecao' | 'outro';
  archangel?: ArchangelId;
  answered: boolean;
  notes?: string;
}

export interface ConsecrationResult {
  devoteeName: string;
  intention: string;
  prayerRafael: string;
  prayerGabriel: string;
  prayerMiguel: string;
  biblicalPromise: string;
  divineDecree: string;
}
