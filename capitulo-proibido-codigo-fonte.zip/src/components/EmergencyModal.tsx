import React, { useState } from 'react';
import { PRAYERS_DATA } from '../data/prayersData';
import { Language, ArchangelId } from '../types';
import { sacredAudio, speechNarrator } from '../utils/audioSystem';
import { 
  AlertCircle, 
  X, 
  Play, 
  Pause, 
  RotateCcw, 
  ShieldAlert, 
  Flame, 
  HeartPulse, 
  Coins 
} from 'lucide-react';

interface EmergencyModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const EmergencyModal: React.FC<EmergencyModalProps> = ({
  isOpen,
  onClose,
  lang
}) => {
  if (!isOpen) return null;
  const isPt = lang === 'pt';

  const [selectedArchangel, setSelectedArchangel] = useState<ArchangelId>('miguel');
  const [isSpeaking, setIsSpeaking] = useState(false);

  const prayer = PRAYERS_DATA.find(p => p.id === selectedArchangel)!;

  const handleSpeak = (text: string) => {
    sacredAudio.playCathedralChime();
    sacredAudio.playSacredFrequency(prayer.frequencyHz, 0.08);

    setIsSpeaking(true);
    speechNarrator.speak({
      text,
      lang,
      onStart: () => setIsSpeaking(true),
      onEnd: () => {
        setIsSpeaking(false);
        sacredAudio.stopSacredFrequency();
      }
    });
  };

  const handleStop = () => {
    speechNarrator.stop();
    sacredAudio.stopSacredFrequency();
    setIsSpeaking(false);
  };

  const handleClose = () => {
    handleStop();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-2xl rounded-3xl p-6 sm:p-8 bg-slate-950 border-2 border-rose-500/50 shadow-2xl shadow-rose-950/80 text-white">
        {/* Close Button */}
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white bg-slate-900 border border-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 rounded-2xl bg-rose-500/20 border border-rose-500/40 text-rose-400">
            <AlertCircle className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-rose-400 bg-rose-950/80 px-2.5 py-0.5 rounded-full border border-rose-500/30">
              {isPt ? 'Socorro Sagrado Imediato' : 'Auxilio Sagrado Inmediato'}
            </span>
            <h3 className="font-serif-sacred text-xl sm:text-2xl font-bold text-slate-100 mt-1">
              {isPt ? 'Oração de Emergência em 1 Clique' : 'Oración de Emergencia en 1 Clic'}
            </h3>
          </div>
        </div>

        <p className="text-xs sm:text-sm text-slate-300 mb-6">
          {isPt
            ? 'Para momentos de angústia repentina, dor insuportável, cobrança aflitiva ou sensação de perigo espiritual.'
            : 'Para momentos de angustia repentina, dolor insoportable, deudas agobiantes o peligro espiritual inminente.'}
        </p>

        {/* 3 Emergency Types Selector */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
          <button
            onClick={() => { handleStop(); setSelectedArchangel('rafael'); }}
            className={`p-3 rounded-2xl border text-left transition-all ${
              selectedArchangel === 'rafael'
                ? 'bg-emerald-950/40 border-emerald-400 text-emerald-200 shadow-md scale-102'
                : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <HeartPulse className="w-5 h-5 text-emerald-400 mb-1.5" />
            <div className="font-serif-sacred font-bold text-xs">
              {isPt ? 'Saúde / Dor Aguda' : 'Salud / Dolor Agudo'}
            </div>
            <div className="text-[10px] text-slate-500 mt-0.5">San Rafael</div>
          </button>

          <button
            onClick={() => { handleStop(); setSelectedArchangel('gabriel'); }}
            className={`p-3 rounded-2xl border text-left transition-all ${
              selectedArchangel === 'gabriel'
                ? 'bg-amber-950/40 border-amber-400 text-amber-200 shadow-md scale-102'
                : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Coins className="w-5 h-5 text-amber-400 mb-1.5" />
            <div className="font-serif-sacred font-bold text-xs">
              {isPt ? 'Dívida / Falta Urgente' : 'Deuda / Falta Urgente'}
            </div>
            <div className="text-[10px] text-slate-500 mt-0.5">San Gabriel</div>
          </button>

          <button
            onClick={() => { handleStop(); setSelectedArchangel('miguel'); }}
            className={`p-3 rounded-2xl border text-left transition-all ${
              selectedArchangel === 'miguel'
                ? 'bg-blue-950/40 border-blue-400 text-blue-200 shadow-md scale-102'
                : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldAlert className="w-5 h-5 text-blue-400 mb-1.5" />
            <div className="font-serif-sacred font-bold text-xs">
              {isPt ? 'Perigo / Inveja / Medo' : 'Peligro / Envidia / Miedo'}
            </div>
            <div className="text-[10px] text-slate-500 mt-0.5">San Miguel</div>
          </button>
        </div>

        {/* Selected Emergency Prayer Box */}
        <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <span className="font-serif-sacred font-bold text-amber-300 text-sm">
              {isPt ? prayer.emergencyPrayer.titlePt : prayer.emergencyPrayer.titleEs}
            </span>
            <span className="text-[11px] font-mono text-slate-400">
              {prayer.frequencyHz} Hz
            </span>
          </div>

          <p className="font-scripture text-base sm:text-lg text-slate-100 leading-relaxed italic">
            «{isPt ? prayer.emergencyPrayer.textPt : prayer.emergencyPrayer.textEs}»
          </p>

          <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
            <span className="text-[11px] text-slate-400">
              {isPt ? 'Repita 3 vezes com fé profunda.' : 'Repite 3 veces con fe profunda.'}
            </span>

            <div className="flex items-center gap-2">
              {!isSpeaking ? (
                <button
                  onClick={() => handleSpeak(isPt ? prayer.emergencyPrayer.textPt : prayer.emergencyPrayer.textEs)}
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow"
                >
                  <Play className="w-3.5 h-3.5 fill-slate-950" />
                  <span>{isPt ? 'Ouvir Clamor' : 'Escuchar Clamor'}</span>
                </button>
              ) : (
                <button
                  onClick={handleStop}
                  className="px-4 py-2 rounded-xl bg-rose-500/20 text-rose-300 border border-rose-500/40 text-xs font-bold flex items-center gap-1.5"
                >
                  <Pause className="w-3.5 h-3.5" />
                  <span>{isPt ? 'Parar' : 'Detener'}</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
