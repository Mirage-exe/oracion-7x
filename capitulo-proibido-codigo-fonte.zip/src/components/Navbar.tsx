import React from 'react';
import { 
  Sparkles, 
  Flame, 
  Volume2, 
  VolumeX, 
  AlertCircle, 
  Smartphone,
  LogOut,
  Download
} from 'lucide-react';
import { Language } from '../types';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  lang: Language;
  setLang: (lang: Language) => void;
  isAmbientPlaying: boolean;
  toggleAmbientSound: () => void;
  onOpenEmergency: () => void;
  onOpenInstallGuide: () => void;
  onOpenDownloadZip: () => void;
  userEmail: string;
  onLogout: () => void;
  streakDays: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  lang,
  setLang,
  isAmbientPlaying,
  toggleAmbientSound,
  onOpenEmergency,
  onOpenInstallGuide,
  onOpenDownloadZip,
  userEmail,
  onLogout,
  streakDays
}) => {
  const isPt = lang === 'pt';

  return (
    <header className="sticky top-0 z-40 backdrop-blur-xl bg-slate-950/90 border-b border-amber-500/20 shadow-2xl">
      {/* Top sacred banner */}
      <div className="bg-gradient-to-r from-amber-950/80 via-amber-900/60 to-slate-950 px-3 py-1 text-center border-b border-amber-500/10 flex items-center justify-between text-xs">
        <div className="flex items-center gap-1.5 text-amber-300 font-medium truncate">
          <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0 animate-pulse" />
          <span className="truncate">
            {isPt 
              ? 'O Capítulo Proibido • Padre Juan Bautista'
              : 'El Capítulo Prohibido • Padre Juan Bautista'}
          </span>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <div className="flex items-center gap-1 bg-amber-500/15 px-2 py-0.5 rounded-full border border-amber-500/20 text-amber-300 text-[11px]">
            <Flame className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
            <span className="font-bold">{streakDays}</span>
            <span>{isPt ? 'dias' : 'días'}</span>
          </div>

          <button
            onClick={onLogout}
            title={isPt ? 'Trocar de Conta / Sair' : 'Cambiar de Cuenta / Salir'}
            className="text-slate-400 hover:text-rose-400 p-1 rounded-md transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-18">
          {/* Logo & title */}
          <div 
            onClick={() => setCurrentTab('flow')}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="relative flex items-center justify-center w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-gradient-to-br from-amber-500 via-amber-600 to-amber-800 text-slate-950 shadow-md shadow-amber-500/20 border border-amber-300/40 shrink-0">
              <span className="font-serif-sacred text-xl font-bold">Ω</span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-serif-sacred text-sm sm:text-lg font-bold tracking-wide text-amber-100">
                  {isPt ? 'O Capítulo Proibido' : 'El Capítulo Prohibido'}
                </span>
              </div>
              <p className="text-[11px] text-amber-400/90 font-medium">
                Rafael ➔ Gabriel ➔ Miguel
              </p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-1.5 sm:gap-2.5">
            {/* Download ZIP button */}
            <button
              onClick={onOpenDownloadZip}
              title={isPt ? 'Baixar Arquivos ZIP' : 'Descargar Archivos ZIP'}
              className="px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 transition-all shadow-sm"
            >
              <Download className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden lg:inline">{isPt ? 'Baixar ZIP' : 'Descargar ZIP'}</span>
            </button>

            {/* Install on mobile button */}
            <button
              onClick={onOpenInstallGuide}
              className="px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 bg-gradient-to-r from-amber-500/20 to-yellow-500/20 text-amber-200 hover:bg-amber-500/30 border border-amber-400/40 transition-all shadow-sm"
            >
              <Smartphone className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">{isPt ? 'Instalar no Celular' : 'Instalar en Celular'}</span>
              <span className="sm:hidden">{isPt ? 'Instalar' : 'Instalar'}</span>
            </button>

            {/* Ambient Sound (432Hz) toggle */}
            <button
              onClick={toggleAmbientSound}
              title={isAmbientPlaying ? (isPt ? 'Desativar Frequência Sagrada' : 'Desactivar Frecuencia Sagrada') : (isPt ? 'Ativar Frequência Sagrada 432Hz' : 'Activar Frecuencia Sagrada 432Hz')}
              className={`p-2 rounded-xl text-xs font-medium flex items-center gap-1 transition-all border ${
                isAmbientPlaying
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-sm shadow-amber-500/20 animate-pulse'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border-slate-800'
              }`}
            >
              {isAmbientPlaying ? <Volume2 className="w-4 h-4 text-amber-400" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* Emergency Button */}
            <button
              onClick={onOpenEmergency}
              className="px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 bg-rose-950/80 text-rose-300 hover:bg-rose-900 border border-rose-500/30 shadow-sm shadow-rose-950/50"
            >
              <AlertCircle className="w-3.5 h-3.5 text-rose-400 animate-bounce" />
              <span className="hidden sm:inline">{isPt ? 'Socorro Urgente' : 'Auxilio Inmediato'}</span>
              <span className="sm:hidden">{isPt ? 'Socorro' : 'Auxilio'}</span>
            </button>

            {/* Language toggle */}
            <div className="flex items-center rounded-xl bg-slate-900 border border-slate-800 p-0.5 text-xs font-bold">
              <button
                onClick={() => setLang('es')}
                className={`px-2 py-1 rounded-lg transition-all ${
                  lang === 'es' ? 'bg-amber-500 text-slate-950 shadow' : 'text-slate-400'
                }`}
              >
                ES
              </button>
              <button
                onClick={() => setLang('pt')}
                className={`px-2 py-1 rounded-lg transition-all ${
                  lang === 'pt' ? 'bg-amber-500 text-slate-950 shadow' : 'text-slate-400'
                }`}
              >
                PT
              </button>
            </div>
          </div>
        </div>

        {/* Desktop Tab Navigation row */}
        <div className="hidden md:flex items-center gap-1 overflow-x-auto py-2.5 scrollbar-none border-t border-slate-800/80 text-xs sm:text-sm">
          {[
            { id: 'flow', labelEs: '✨ Oración Guiada (3 en 1)', labelPt: '✨ Oração Guiada (3 em 1)' },
            { id: 'manuscript', labelEs: '📜 El Manuscrito Sagrado', labelPt: '📜 O Manuscrito Sagrado' },
            { id: 'holywater', labelEs: '💧 Ritual del Agua Sagrada', labelPt: '💧 Ritual da Água Sagrada' },
            { id: 'tracker', labelEs: '📅 Guía del Orden (21 Días)', labelPt: '📅 Guia da Ordem (21 Dias)' },
            { id: 'consecrate', labelEs: '⚡ Petición Personalizada', labelPt: '⚡ Oração Personalizada' },
            { id: 'journal', labelEs: '📖 Milagros & Testimonios', labelPt: '📖 Milagres & Depoimentos' },
          ].map(tab => {
            const isActive = currentTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setCurrentTab(tab.id)}
                className={`whitespace-nowrap px-3.5 py-1.5 rounded-lg font-medium transition-all flex items-center gap-1.5 ${
                  isActive
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm shadow-amber-500/10'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60 border border-transparent'
                }`}
              >
                <span>{isPt ? tab.labelPt : tab.labelEs}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
