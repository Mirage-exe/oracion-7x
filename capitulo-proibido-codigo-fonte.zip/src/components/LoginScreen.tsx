import React, { useState } from 'react';
import { Sparkles, Lock, Mail, KeyRound, AlertCircle, CheckCircle2, ShieldCheck, Heart } from 'lucide-react';
import { Language } from '../types';

interface LoginScreenProps {
  lang: Language;
  setLang: (lang: Language) => void;
  onLoginSuccess: (email: string) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  lang,
  setLang,
  onLoginSuccess,
}) => {
  const isPt = lang === 'pt';
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const trimmedEmail = email.trim();
    const trimmedPass = password.trim();

    if (!trimmedEmail || !trimmedEmail.includes('@')) {
      setErrorMsg(
        isPt
          ? 'Por favor, digite um e-mail válido (o mesmo utilizado na compra).'
          : 'Por favor, ingresa un correo electrónico válido (el mismo de tu compra).'
      );
      return;
    }

    // Password requirement: member@123
    if (trimmedPass !== 'member@123') {
      setErrorMsg(
        isPt
          ? 'Senha incorreta. A senha oficial de membro é: member@123'
          : 'Contraseña incorrecta. La contraseña oficial de miembro es: member@123'
      );
      return;
    }

    // Success!
    onLoginSuccess(trimmedEmail);
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col justify-center items-center px-4 py-8 sm:px-6 selection:bg-amber-500/30 selection:text-amber-200">
      {/* Top language selector */}
      <div className="w-full max-w-md flex justify-between items-center mb-6">
        <div className="flex items-center gap-2 text-amber-400 text-xs font-medium">
          <ShieldCheck className="w-4 h-4" />
          <span>{isPt ? 'Ambiente Seguro de Acesso' : 'Ambiente Seguro de Acceso'}</span>
        </div>
        <div className="flex items-center rounded-xl bg-slate-900 border border-slate-800 p-1 text-xs font-bold">
          <button
            onClick={() => setLang('es')}
            className={`px-3 py-1 rounded-lg transition-all ${
              lang === 'es' ? 'bg-amber-500 text-slate-950 shadow' : 'text-slate-400'
            }`}
          >
            ES
          </button>
          <button
            onClick={() => setLang('pt')}
            className={`px-3 py-1 rounded-lg transition-all ${
              lang === 'pt' ? 'bg-amber-500 text-slate-950 shadow' : 'text-slate-400'
            }`}
          >
            PT
          </button>
        </div>
      </div>

      {/* Main Login Card */}
      <div className="w-full max-w-md rounded-3xl p-6 sm:p-8 bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950 border-2 border-amber-500/30 shadow-2xl shadow-amber-950/40 relative overflow-hidden">
        {/* Subtle glow background */}
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Sacred Header */}
        <div className="text-center relative z-10 mb-6">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-amber-500 via-amber-600 to-amber-800 text-slate-950 shadow-xl shadow-amber-500/30 flex items-center justify-center border-2 border-amber-300/40 mb-3">
            <span className="font-serif-sacred text-2xl font-bold">Ω</span>
          </div>

          <h1 className="font-serif-sacred text-2xl sm:text-3xl font-bold text-amber-100 tracking-wide">
            {isPt ? 'O Capítulo Proibido' : 'El Capítulo Prohibido'}
          </h1>
          <p className="text-xs uppercase tracking-widest text-amber-400 font-semibold mt-1">
            {isPt ? 'Área de Membros • Padre Juan Bautista' : 'Área de Miembros • Padre Juan Bautista'}
          </p>
        </div>

        {/* Important Purchase Message (as requested by user) */}
        <div className="p-4 rounded-2xl bg-amber-950/30 border border-amber-500/30 mb-6 text-center">
          <p className="text-xs sm:text-sm text-amber-200 leading-relaxed font-medium">
            {isPt
              ? '🔒 Digite abaixo o mesmo e-mail que você utilizou no momento da compra para liberar o seu acesso sagrado.'
              : '🔒 Ingresa a continuación el mismo correo con el que realizaste tu compra para desbloquear tu acceso sagrado.'}
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-5">
          {errorMsg && (
            <div className="p-3.5 rounded-xl bg-rose-950/60 border border-rose-500/50 text-rose-200 text-xs flex items-start gap-2.5 animate-fade-in">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
              {isPt ? 'Seu E-mail da Compra' : 'Tu Correo de Compra'}
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                <Mail className="w-5 h-5" />
              </div>
              <input
                type="email"
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder={isPt ? 'seuemail@exemplo.com' : 'tucorreo@ejemplo.com'}
                className="w-full pl-11 pr-4 py-3.5 rounded-2xl bg-slate-950 border border-slate-800 text-white placeholder-slate-600 focus:outline-none focus:border-amber-400 text-base"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-300">
                {isPt ? 'Senha de Acesso' : 'Contraseña de Acceso'}
              </label>
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="text-[11px] text-amber-400 hover:text-amber-300 font-semibold"
              >
                {showPassword ? (isPt ? 'Ocultar' : 'Ocultar') : (isPt ? 'Mostrar' : 'Mostrar')}
              </button>
            </div>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                <KeyRound className="w-5 h-5" />
              </div>
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="member@123"
                className="w-full pl-11 pr-4 py-3.5 rounded-2xl bg-slate-950 border border-slate-800 text-white placeholder-slate-600 focus:outline-none focus:border-amber-400 text-base"
              />
            </div>
          </div>

          {/* Senior friendly helper note */}
          <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
            <span>{isPt ? 'Senha de membro:' : 'Contraseña de miembro:'}</span>
            <span className="font-mono text-amber-300 font-bold text-xs bg-slate-950 px-2 py-0.5 rounded border border-amber-500/20">
              member@123
            </span>
          </div>

          <button
            type="submit"
            className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-bold text-base tracking-wide flex items-center justify-center gap-2 shadow-xl shadow-amber-500/25 transition-all transform active:scale-98"
          >
            <Lock className="w-5 h-5 fill-slate-950" />
            <span>{isPt ? 'ENTRAR NO APLICATIVO' : 'INGRESAR AL APLICATIVO'}</span>
          </button>
        </form>

        {/* Footer reassurance */}
        <div className="mt-6 pt-4 border-t border-slate-900 text-center text-xs text-slate-500">
          <p className="flex items-center justify-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-400/80" />
            <span>{isPt ? 'Rafael • Gabriel • Miguel' : 'Rafael • Gabriel • Miguel'}</span>
          </p>
          <p className="text-[11px] text-slate-600 mt-1">
            {isPt ? 'Seu acesso permanece conectado no seu celular.' : 'Tu acceso permanece conectado en tu celular.'}
          </p>
        </div>
      </div>
    </div>
  );
};
