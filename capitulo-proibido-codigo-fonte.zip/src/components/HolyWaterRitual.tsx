import React, { useState } from 'react';
import { HOLY_WATER_STEPS } from '../data/prayersData';
import { Language } from '../types';
import { sacredAudio } from '../utils/audioSystem';
import { 
  Droplets, 
  Sparkles, 
  ChevronRight, 
  ChevronLeft, 
  CheckCircle2, 
  RotateCcw, 
  ShieldAlert, 
  Home
} from 'lucide-react';

interface HolyWaterRitualProps {
  lang: Language;
}

export const HolyWaterRitual: React.FC<HolyWaterRitualProps> = ({ lang }) => {
  const isPt = lang === 'pt';
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<boolean[]>([false, false, false, false]);

  const stepData = HOLY_WATER_STEPS[currentStep];

  const handleNext = () => {
    sacredAudio.playCathedralChime();
    setCompletedSteps(prev => {
      const u = [...prev];
      u[currentStep] = true;
      return u;
    });
    if (currentStep < HOLY_WATER_STEPS.length - 1) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const getGobletGlow = () => {
    if (currentStep === 1) return 'border-emerald-400 bg-emerald-500/20 shadow-[0_0_60px_rgba(16,185,129,0.4)]';
    if (currentStep === 2) return 'border-amber-400 bg-amber-500/20 shadow-[0_0_60px_rgba(245,158,11,0.4)]';
    if (currentStep === 3) return 'border-blue-400 bg-blue-500/20 shadow-[0_0_60px_rgba(59,130,246,0.4)]';
    return 'border-cyan-400/50 bg-cyan-500/10 shadow-[0_0_40px_rgba(6,182,212,0.25)]';
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in">
      {/* Header Banner */}
      <div className="relative rounded-3xl p-6 sm:p-8 bg-gradient-to-b from-cyan-950/40 via-slate-900 to-slate-950 border border-cyan-500/30 overflow-hidden shadow-2xl text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-semibold uppercase tracking-wider mb-3">
          <Droplets className="w-3.5 h-3.5 text-cyan-400" />
          <span>{isPt ? 'Bônus Exclusivo da Revelação' : 'Bono Exclusivo de la Revelación'}</span>
        </div>

        <h2 className="font-serif-sacred text-2xl sm:text-3xl md:text-4xl font-bold text-slate-100 tracking-wide">
          {isPt 
            ? 'O Ritual da Água Sagrada dos Três Arcanjos'
            : 'El Ritual del Agua Sagrada de los Tres Arcángeles'}
        </h2>

        <p className="mt-2 text-slate-300 text-sm max-w-xl mx-auto">
          {isPt
            ? 'O antigo segredo dos monges que o Padre Juan Bautista ensinou para purificar sua casa, dissolver energia pesada e preparar a atmosfera para o milagre divino.'
            : 'El antiguo secreto de los monjes que el Padre Juan Bautista enseñó para purificar el hogar, disolver la mala energía y preparar la atmósfera para el milagro divino.'}
        </p>

        {/* Step circles */}
        <div className="flex items-center justify-center gap-2 sm:gap-4 mt-6">
          {HOLY_WATER_STEPS.map((s, idx) => {
            const isCur = currentStep === idx;
            const isDone = completedSteps[idx];
            return (
              <button
                key={s.step}
                onClick={() => setCurrentStep(idx)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-semibold transition-all ${
                  isCur
                    ? 'border-cyan-400 bg-cyan-500/20 text-cyan-200 shadow-md scale-105'
                    : isDone
                    ? 'border-emerald-500/50 bg-emerald-950/30 text-emerald-300'
                    : 'border-slate-800 bg-slate-950 text-slate-500 hover:text-slate-300'
                }`}
              >
                <span>{isPt ? `Etapa ${idx + 1}` : `Paso ${idx + 1}`}</span>
                {isDone && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Interactive Wizard Box */}
      <div className="relative rounded-3xl p-6 sm:p-10 bg-slate-900/90 border border-slate-800 shadow-2xl">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          {/* Left: The Goblet Illustration */}
          <div className="md:col-span-4 flex flex-col items-center justify-center p-6 rounded-2xl bg-slate-950/80 border border-slate-800/80">
            <div className={`relative w-28 h-36 rounded-b-full border-2 flex items-center justify-center transition-all duration-700 ${getGobletGlow()}`}>
              {/* Goblet stem */}
              <div className="absolute -bottom-6 w-3 h-6 bg-slate-700" />
              <div className="absolute -bottom-8 w-16 h-2 rounded-full bg-slate-600" />
              
              <Droplets className="w-12 h-12 text-cyan-200 animate-pulse" />
              <div className="absolute inset-0 bg-gradient-to-t from-cyan-400/20 to-transparent rounded-b-full" />
            </div>

            <div className="mt-12 text-center">
              <span className="text-xs font-serif font-bold text-slate-200 block">
                {currentStep === 0 && (isPt ? 'Água Pura Natural' : 'Agua Pura Natural')}
                {currentStep === 1 && (isPt ? 'Ativada com Rafael (Cura)' : 'Activada con Rafael (Sanación)')}
                {currentStep === 2 && (isPt ? 'Imantada com Gabriel (Abundância)' : 'Imantada con Gabriel (Abundancia)')}
                {currentStep === 3 && (isPt ? 'Selada com Miguel (Blindagem)' : 'Sellada con Miguel (Blindaje)')}
              </span>
              <span className="text-[11px] text-slate-400 mt-1 block">
                {isPt ? 'Consagração do Vaso Sagrado' : 'Consagración del Vaso Sagrado'}
              </span>
            </div>
          </div>

          {/* Right: Step instructions & Invocations */}
          <div className="md:col-span-8 space-y-5">
            <div>
              <span className="text-xs font-semibold uppercase tracking-wider text-cyan-400 bg-cyan-950/60 px-3 py-1 rounded-full border border-cyan-500/30">
                {isPt ? `Passo ${currentStep + 1} de 4` : `Paso ${currentStep + 1} de 4`}
              </span>
              <h3 className="font-serif-sacred text-xl sm:text-2xl font-bold text-white mt-3">
                {isPt ? stepData.titlePt : stepData.titleEs}
              </h3>
            </div>

            <p className="text-slate-200 text-sm sm:text-base leading-relaxed">
              {isPt ? stepData.instructionPt : stepData.instructionEs}
            </p>

            <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 text-xs text-slate-400 flex items-start gap-3">
              <Home className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
              <span>{isPt ? stepData.archangelNotePt : stepData.archangelNoteEs}</span>
            </div>

            {/* Sacred Inscription to recite */}
            <div className="p-5 rounded-2xl bg-gradient-to-r from-amber-950/20 via-slate-950 to-slate-950 border border-amber-500/30">
              <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wider block mb-1">
                {isPt ? 'Palavras Sagradas de Ativação:' : 'Palabras Sagradas de Activación:'}
              </span>
              <p className="font-scripture text-base sm:text-lg text-amber-100 italic leading-snug">
                «{isPt ? stepData.invocationPt : stepData.invocationEs}»
              </p>
            </div>

            {/* Wizard Navigation */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-800">
              <button
                onClick={handlePrev}
                disabled={currentStep === 0}
                className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  currentStep === 0
                    ? 'opacity-40 cursor-not-allowed text-slate-600'
                    : 'text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700'
                }`}
              >
                <ChevronLeft className="w-4 h-4" />
                <span>{isPt ? 'Anterior' : 'Anterior'}</span>
              </button>

              <button
                onClick={handleNext}
                className="px-5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white shadow-lg shadow-cyan-600/30 transition-all hover:scale-102"
              >
                <span>
                  {currentStep === HOLY_WATER_STEPS.length - 1
                    ? (isPt ? 'Concluir Ritual' : 'Concluir Ritual')
                    : (isPt ? 'Avançar Etapa' : 'Avanzar Paso')}
                </span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
