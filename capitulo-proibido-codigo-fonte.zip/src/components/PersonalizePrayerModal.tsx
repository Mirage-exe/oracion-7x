import React, { useState } from 'react';
import { Language, ConsecrationResult } from '../types';
import { generateAutonomousConsecration } from '../utils/autonomousConsecration';
import { sacredAudio, speechNarrator } from '../utils/audioSystem';
import { 
  Sparkles, 
  Play, 
  Pause, 
  RotateCcw, 
  BookmarkPlus, 
  Check, 
  Loader2
} from 'lucide-react';

interface PersonalizePrayerModalProps {
  lang: Language;
  onSaveToJournal: (title: string, description: string, category: 'saude' | 'financas' | 'familia' | 'protecao' | 'outro') => void;
}

export const PersonalizePrayerModal: React.FC<PersonalizePrayerModalProps> = ({
  lang,
  onSaveToJournal,
}) => {
  const isPt = lang === 'pt';
  const [devoteeName, setDevoteeName] = useState('');
  const [category, setCategory] = useState<'saude' | 'financas' | 'familia' | 'protecao'>('financas');
  const [intention, setIntention] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ConsecrationResult | null>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isSaved, setIsSaved] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!intention.trim()) return;

    setLoading(true);
    setIsSaved(false);

    // Instant & autonomous generation with zero API dependency
    setTimeout(() => {
      const generated = generateAutonomousConsecration(
        devoteeName,
        intention,
        category,
        lang
      );
      setResult(generated);
      sacredAudio.playCathedralChime();
      setLoading(false);
    }, 400);
  };

  const handleSpeak = () => {
    if (!result) return;
    const textToSpeak = `${isPt ? 'Oração a São Rafael' : 'Oración a San Rafael'}: ${result.prayerRafael}. ${isPt ? 'Oração a São Gabriel' : 'Oración a San Gabriel'}: ${result.prayerGabriel}. ${isPt ? 'Oração a São Miguel' : 'Oración a San Miguel'}: ${result.prayerMiguel}. ${result.divineDecree}`;
    
    setIsSpeaking(true);
    sacredAudio.playSacredFrequency(528, 0.05);

    speechNarrator.speak({
      text: textToSpeak,
      lang,
      onStart: () => setIsSpeaking(true),
      onEnd: () => {
        setIsSpeaking(false);
        sacredAudio.stopSacredFrequency();
      }
    });
  };

  const handlePause = () => {
    speechNarrator.pause();
    setIsSpeaking(false);
  };

  const handleStop = () => {
    speechNarrator.stop();
    sacredAudio.stopSacredFrequency();
    setIsSpeaking(false);
  };

  const handleSave = () => {
    if (!result) return;
    onSaveToJournal(
      `${isPt ? 'Consagração de' : 'Consagración de'} ${result.devoteeName} (${category})`,
      `${result.intention}\n\n[Decreto]: ${result.divineDecree}`,
      category
    );
    setIsSaved(true);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in">
      {/* Header Banner */}
      <div className="relative rounded-3xl p-6 sm:p-8 bg-gradient-to-b from-amber-950/40 via-slate-900 to-slate-950 border border-amber-500/30 overflow-hidden shadow-2xl text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold uppercase tracking-wider mb-3">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>{isPt ? 'Consagração Sob Medida' : 'Consagración a Medida'}</span>
        </div>

        <h2 className="font-serif-sacred text-2xl sm:text-3xl md:text-4xl font-bold text-amber-100 tracking-wide">
          {isPt ? 'Oração Personalizada por Intenção' : 'Oración Personalizada por Intención'}
        </h2>

        <p className="mt-2 text-slate-300 text-sm max-w-xl mx-auto">
          {isPt
            ? 'Apresente seu nome e sua necessidade urgente. O sistema canalizará sua petição na Ordem Divina dos 3 Arcanjos com base nos princípios do Capítulo Proibido.'
            : 'Presenta tu nombre y necesidad urgente. El sistema canalizará tu petición en el Orden Divino de los 3 Arcángeles según las enseñanzas del Capítulo Prohibido.'}
        </p>
      </div>

      {/* Input Form */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                {isPt ? 'Seu Nome / Nome da Pessoa' : 'Tu Nombre / Nombre de la Persona'}
              </label>
              <input
                type="text"
                value={devoteeName}
                onChange={e => setDevoteeName(e.target.value)}
                placeholder={isPt ? 'Ex: Maria, Carlos, Família Silva...' : 'Ej: María, Carlos, Familia Silva...'}
                className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-600 focus:outline-none focus:border-amber-500/60 text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                {isPt ? 'Área da Vida' : 'Área de la Vida'}
              </label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value as any)}
                className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-amber-500/60 text-sm"
              >
                <option value="financas">{isPt ? '💰 Dívidas & Prosperidade Financeira' : '💰 Deudas & Prosperidad Financiera'}</option>
                <option value="saude">{isPt ? '🌿 Saúde Física & Cura de Doenças' : '🌿 Salud Física & Sanación de Dolores'}</option>
                <option value="familia">{isPt ? '🕊️ Casamento, Filhos & Paz no Lar' : '🕊️ Matrimonio, Hijos & Paz del Hogar'}</option>
                <option value="protecao">{isPt ? '🛡️ Proteção Contra Inveja & Perigos' : '🛡️ Protección Contra Envidia & Peligros'}</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
              {isPt ? 'Descreva Sua Aflição ou Pedido de Milagre' : 'Describe Tu Aflicción o Petición de Milagro'}
            </label>
            <textarea
              rows={3}
              required
              value={intention}
              onChange={e => setIntention(e.target.value)}
              placeholder={isPt 
                ? 'Ex: Preciso pagar R$ 3.500 em dívidas este mês e destravar novas vendas, e peço paz e fim das brigas em meu casamento...'
                : 'Ej: Necesito saldar una deuda urgente este mes, abrir caminos de trabajo y traer salud a mis pulmones...'}
              className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-600 focus:outline-none focus:border-amber-500/60 text-sm"
            />
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-sm flex items-center gap-2 shadow-lg shadow-amber-500/25 transition-all disabled:opacity-50"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-slate-950" />
                  <span>{isPt ? 'Canalizando Oração Sagrada...' : 'Canalizando Oración Sagrada...'}</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 fill-slate-950" />
                  <span>{isPt ? 'Gerar Consagração dos 3 Arcanjos' : 'Generar Consagración de los 3 Arcángeles'}</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      {/* Generated Consecration Display */}
      {result && (
        <div className="p-6 sm:p-10 rounded-3xl bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950 border border-amber-500/40 shadow-2xl space-y-6 animate-fade-in">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
                {isPt ? 'Consagração Gerada para' : 'Consagración Generada para'}
              </span>
              <h3 className="font-serif-sacred text-2xl font-bold text-white mt-1">
                {result.devoteeName}
              </h3>
            </div>

            <div className="flex items-center gap-2">
              {!isSpeaking ? (
                <button
                  onClick={handleSpeak}
                  className="px-4 py-2 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center gap-1.5 hover:bg-amber-500/30 transition-all"
                >
                  <Play className="w-3.5 h-3.5 fill-amber-300" />
                  <span>{isPt ? 'Ouvir Narração' : 'Escuchar Narración'}</span>
                </button>
              ) : (
                <button
                  onClick={handlePause}
                  className="px-4 py-2 rounded-xl bg-amber-500/30 text-amber-300 border border-amber-500/50 text-xs font-bold flex items-center gap-1.5"
                >
                  <Pause className="w-3.5 h-3.5" />
                  <span>{isPt ? 'Pausar' : 'Pausar'}</span>
                </button>
              )}

              {isSpeaking && (
                <button
                  onClick={handleStop}
                  className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              )}

              <button
                onClick={handleSave}
                disabled={isSaved}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-all"
              >
                {isSaved ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <BookmarkPlus className="w-3.5 h-3.5" />}
                <span>{isSaved ? (isPt ? 'Salvo no Diário' : 'Guardado en Diario') : (isPt ? 'Salvar no Diário' : 'Guardar en Diario')}</span>
              </button>
            </div>
          </div>

          {/* 3 Steps Personalized */}
          <div className="space-y-4">
            <div className="p-4 sm:p-5 rounded-2xl bg-emerald-950/20 border border-emerald-500/30">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 block mb-1">
                {isPt ? '1º San Rafael Arcángel (Sanación y Limpieza)' : '1º San Rafael Arcángel (Sanación y Limpieza)'}
              </span>
              <p className="font-scripture text-slate-200 text-base leading-relaxed">
                {result.prayerRafael}
              </p>
            </div>

            <div className="p-4 sm:p-5 rounded-2xl bg-amber-950/20 border border-amber-500/30">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-400 block mb-1">
                {isPt ? '2º San Gabriel Arcángel (Provisión y Puertas Abiertas)' : '2º San Gabriel Arcángel (Provisión y Puertas Abiertas)'}
              </span>
              <p className="font-scripture text-slate-200 text-base leading-relaxed">
                {result.prayerGabriel}
              </p>
            </div>

            <div className="p-4 sm:p-5 rounded-2xl bg-blue-950/20 border border-blue-500/30">
              <span className="text-xs font-bold uppercase tracking-wider text-blue-400 block mb-1">
                {isPt ? '3º San Miguel Arcángel (Blindaje y Sellado)' : '3º San Miguel Arcángel (Blindaje y Sellado)'}
              </span>
              <p className="font-scripture text-slate-200 text-base leading-relaxed">
                {result.prayerMiguel}
              </p>
            </div>
          </div>

          {/* Biblical Promise & Divine Decree */}
          <div className="p-5 rounded-2xl bg-slate-950 border border-amber-500/30 space-y-3">
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                {isPt ? 'Promessa Bíblica de Respaldo' : 'Promesa Bíblica de Respaldo'}
              </span>
              <p className="text-xs text-amber-300 italic mt-0.5">
                {result.biblicalPromise}
              </p>
            </div>

            <div className="pt-2 border-t border-slate-900">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                {isPt ? 'Decreto Sagrado de Vitória (Repita com Fé)' : 'Decreto Sagrado de Victoria (Repite con Fe)'}
              </span>
              <p className="font-serif-sacred text-base text-amber-100 font-bold mt-1">
                «{result.divineDecree}»
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
