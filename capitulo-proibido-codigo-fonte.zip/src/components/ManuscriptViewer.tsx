import React, { useState } from 'react';
import { VATICAN_MANUSCRIPT_PROLOGUE, PRAYERS_DATA } from '../data/prayersData';
import { Language } from '../types';
import { ScrollText, Feather } from 'lucide-react';

interface ManuscriptViewerProps {
  lang: Language;
}

export const ManuscriptViewer: React.FC<ManuscriptViewerProps> = ({ lang }) => {
  const isPt = lang === 'pt';
  const [showLatin, setShowLatin] = useState(false);

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in">
      <div className="relative rounded-3xl p-6 sm:p-10 border-2 border-amber-500/40 bg-[#12100d] shadow-2xl parchment-texture text-amber-100 overflow-hidden">
        <div className="text-center max-w-2xl mx-auto relative z-10 pt-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold uppercase tracking-wider mb-3">
            <ScrollText className="w-3.5 h-3.5 text-amber-400" />
            <span>{isPt ? 'Manuscrito Original do Vaticano' : 'Manuscrito Original del Vaticano'}</span>
          </div>

          <h2 className="font-serif-sacred text-2xl sm:text-3xl md:text-4xl font-bold text-amber-200 tracking-wide">
            {isPt ? 'O Capítulo Proibido' : 'El Capítulo Prohibido'}
          </h2>
          <p className="text-xs uppercase tracking-widest text-amber-400/80 font-mono mt-1">
            Archivum Secretum Vaticanum • Anno Domini MDXXIV
          </p>

          <p className="mt-4 text-slate-300 text-sm leading-relaxed">
            {isPt 
              ? 'Guardado e censurado por mais de 500 anos nas estantes antigas de Roma. Revelado pelo Padre Juan Bautista sob orientação divina para libertar os fiéis da opressão, da dor e da miséria.'
              : 'Guardado y censurado por más de 500 años en los viejos estantes de Roma. Revelado por el Padre Juan Bautista bajo guía divina para liberar a los fieles de la opresión, el dolor y la miseria.'}
          </p>

          <div className="mt-4 flex justify-center">
            <button
              onClick={() => setShowLatin(!showLatin)}
              className="text-xs font-mono px-3 py-1.5 rounded-lg border border-amber-500/30 bg-amber-950/30 text-amber-300 hover:bg-amber-900/40 transition-colors"
            >
              {showLatin 
                ? (isPt ? 'Ocultar Latim Eclesiástico' : 'Ocultar Latín Eclesiástico')
                : (isPt ? 'Ver Texto em Latim Eclesiástico' : 'Ver Texto en Latín Eclesiástico')}
            </button>
          </div>
        </div>

        <div className="my-8 p-6 rounded-2xl bg-black/40 border border-amber-500/30 shadow-inner">
          <div className="text-center font-serif text-amber-300/90 text-sm italic whitespace-pre-line leading-relaxed tracking-wide">
            {showLatin ? VATICAN_MANUSCRIPT_PROLOGUE.latin : (isPt ? VATICAN_MANUSCRIPT_PROLOGUE.translationPt : VATICAN_MANUSCRIPT_PROLOGUE.translationEs)}
          </div>
        </div>

        <div className="space-y-6">
          {PRAYERS_DATA.map((prayer) => (
            <div 
              key={prayer.id}
              className="p-6 rounded-2xl bg-amber-950/20 border border-amber-500/25 relative"
            >
              <div className="flex items-center justify-between pb-3 border-b border-amber-500/20">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-amber-500/20 border border-amber-400/40 flex items-center justify-center font-serif font-bold text-amber-300 text-sm">
                    {prayer.order}
                  </div>
                  <div>
                    <h4 className="font-serif-sacred font-bold text-lg text-amber-200">
                      {isPt ? prayer.namePt : prayer.name}
                    </h4>
                    <span className="text-xs text-amber-400/70 font-mono italic">
                      {prayer.latinName}
                    </span>
                  </div>
                </div>
                <span className="text-xs text-slate-400 italic hidden sm:inline">
                  {isPt ? prayer.domainPt : prayer.domain}
                </span>
              </div>

              <div className="mt-4 space-y-3 font-scripture text-slate-200 text-base leading-relaxed">
                {prayer.stanzas[lang].map((stanza, idx) => (
                  <p key={idx} className="indent-4">
                    {stanza}
                  </p>
                ))}
              </div>

              <div className="mt-4 pt-3 border-t border-amber-500/10 text-xs text-amber-400/80 flex items-center gap-2">
                <Feather className="w-3.5 h-3.5" />
                <span>
                  {prayer.order === 1 && (isPt ? 'Deve ser rezada obrigatoriamente primeiro para purificar.' : 'Debe rezarse obligatoriamente primero para purificar.')}
                  {prayer.order === 2 && (isPt ? 'Rezar apenas após Rafael para receber o anúncio de abundância.' : 'Rezar solo tras Rafael para recibir el anuncio de abundancia.')}
                  {prayer.order === 3 && (isPt ? 'Rezar ao final para selar com a espada de fogo e proteger.' : 'Rezar al final para sellar con la espada de fuego y proteger.')}
                </span>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-8 pt-6 border-t border-amber-500/30 text-center">
          <div className="inline-block p-4 rounded-full bg-amber-500/10 border-2 border-amber-400/40 text-amber-300 mb-3 shadow-lg shadow-amber-500/20">
            <span className="font-serif text-2xl font-bold">✠ VERITAS ✠</span>
          </div>
          <p className="text-xs text-slate-400 max-w-lg mx-auto">
            {isPt 
              ? 'Transcrição fiel extraída dos códices eclesiásticos revelados pelo Padre Juan Bautista.'
              : 'Transcripción fiel extraída de los códices eclesiásticos revelados por el Padre Juan Bautista.'}
          </p>
        </div>
      </div>
    </div>
  );
};
