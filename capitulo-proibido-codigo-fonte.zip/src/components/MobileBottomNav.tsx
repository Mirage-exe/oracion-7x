import React from 'react';
import { Sparkles, BookOpen, Droplets, Calendar, ShieldCheck, HeartHandshake } from 'lucide-react';
import { Language } from '../types';

interface MobileBottomNavProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  lang: Language;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  currentTab,
  setCurrentTab,
  lang,
}) => {
  const isPt = lang === 'pt';

  const navItems = [
    { id: 'flow', labelEs: 'Orar', labelPt: 'Orar', icon: Sparkles },
    { id: 'manuscript', labelEs: 'Texto', labelPt: 'Texto', icon: BookOpen },
    { id: 'holywater', labelEs: 'Água', labelPt: 'Água', icon: Droplets },
    { id: 'tracker', labelEs: '21 Días', labelPt: '21 Dias', icon: Calendar },
    { id: 'consecrate', labelEs: 'Petición', labelPt: 'Pedido', icon: ShieldCheck },
    { id: 'journal', labelEs: 'Milagros', labelPt: 'Milagres', icon: HeartHandshake },
  ];

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-xl border-t border-amber-500/20 pb-safe shadow-[0_-10px_25px_-5px_rgba(0,0,0,0.8)]">
      <div className="grid grid-cols-6 h-16 items-center px-1">
        {navItems.map((item) => {
          const isActive = currentTab === item.id;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => {
                setCurrentTab(item.id);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className={`flex flex-col items-center justify-center py-1 transition-all ${
                isActive
                  ? 'text-amber-300 font-bold scale-105'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div
                className={`p-1.5 rounded-xl transition-all ${
                  isActive
                    ? 'bg-amber-500/20 border border-amber-500/40 text-amber-300 shadow-sm shadow-amber-500/20'
                    : 'bg-transparent'
                }`}
              >
                <Icon className="w-5 h-5" />
              </div>
              <span className="text-[10px] mt-0.5 tracking-tight font-medium">
                {isPt ? item.labelPt : item.labelEs}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
