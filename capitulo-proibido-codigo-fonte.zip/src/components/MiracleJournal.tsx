import React, { useState } from 'react';
import { TESTIMONIALS_DATA } from '../data/prayersData';
import { Language, UserJournalEntry } from '../types';
import { 
  HeartHandshake, 
  Sparkles, 
  CheckCircle2, 
  Plus, 
  Trash2, 
  Check, 
  Clock, 
  Quote, 
  ShieldCheck 
} from 'lucide-react';

interface MiracleJournalProps {
  lang: Language;
  entries: UserJournalEntry[];
  onAddEntry: (entry: Omit<UserJournalEntry, 'id'>) => void;
  onToggleAnswered: (id: string) => void;
  onDeleteEntry: (id: string) => void;
}

export const MiracleJournal: React.FC<MiracleJournalProps> = ({
  lang,
  entries,
  onAddEntry,
  onToggleAnswered,
  onDeleteEntry
}) => {
  const isPt = lang === 'pt';
  const [showAddForm, setShowAddForm] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<'saude' | 'financas' | 'familia' | 'protecao' | 'outro'>('financas');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) return;

    onAddEntry({
      title: title.trim(),
      description: description.trim(),
      category,
      date: new Date().toLocaleDateString(isPt ? 'pt-BR' : 'es-ES', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      }),
      answered: false
    });

    setTitle('');
    setDescription('');
    setShowAddForm(false);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-10 animate-fade-in">
      {/* Header Banner */}
      <div className="relative rounded-3xl p-6 sm:p-8 bg-gradient-to-b from-slate-900 to-slate-950 border border-amber-500/30 overflow-hidden shadow-2xl text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold uppercase tracking-wider mb-3">
          <HeartHandshake className="w-3.5 h-3.5 text-amber-400" />
          <span>{isPt ? 'Mural de Fé & Testemunhos' : 'Mural de Fe & Testimonios'}</span>
        </div>

        <h2 className="font-serif-sacred text-2xl sm:text-3xl md:text-4xl font-bold text-amber-100 tracking-wide">
          {isPt ? 'Diário de Bênçãos & Milagres' : 'Diario de Bendiciones & Milagros'}
        </h2>

        <p className="mt-2 text-slate-300 text-sm max-w-xl mx-auto">
          {isPt
            ? 'Veja os testemunhos reais citados na revelação do Padre Juan Bautista e registre cada oração atendida na sua vida.'
            : 'Conoce los testimonios reales citados en la revelación del Padre Juan Bautista y anota cada oración respondida en tu vida.'}
        </p>
      </div>

      {/* Official VSL Testimonials Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-serif-sacred text-xl font-bold text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <span>{isPt ? 'Testemunhos Citados na Revelação' : 'Testimonios Citados en la Revelación'}</span>
          </h3>
          <span className="text-xs text-amber-400/80 font-medium">
            {isPt ? 'Córdoba • Rosario • Mendoza' : 'Córdoba • Rosario • Mendoza'}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {TESTIMONIALS_DATA.map((t) => (
            <div 
              key={t.id}
              className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-col justify-between hover:border-amber-500/40 transition-all duration-300 shadow-lg"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/20">
                    {t.tag}
                  </span>
                  <span className="text-xs text-slate-500 font-medium">
                    {t.location}
                  </span>
                </div>

                <div className="font-serif-sacred font-bold text-lg text-slate-100">
                  {t.name} {t.age ? `(${t.age} años)` : ''}
                </div>

                <div className="my-3 p-3 rounded-xl bg-slate-950/80 border border-slate-800/80 text-amber-200/90 text-xs italic">
                  <Quote className="w-3.5 h-3.5 text-amber-400 mb-1" />
                  «{isPt ? t.quotePt : t.quoteEs}»
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  {isPt ? t.storyPt : t.storyEs}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-emerald-400">
                <span className="flex items-center gap-1 font-semibold">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  {isPt ? 'Testemunho Verificado' : 'Testimonio Verificado'}
                </span>
                <span className="text-slate-500 capitalize">{t.archangel}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* User's Personal Miracle Journal */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <h3 className="font-serif-sacred text-xl font-bold text-white">
              {isPt ? 'Meu Livro de Graças & Orações Respondidas' : 'Mi Libro de Gracias & Oraciones Respondidas'}
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              {isPt 
                ? 'Registre suas intenções e marque com alegria quando Deus responder.' 
                : 'Anota tus intenciones y márcalas con gozo cuando Dios responda.'}
            </p>
          </div>

          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>{isPt ? 'Nova Entrada de Bênção' : 'Nueva Entrada de Bendición'}</span>
          </button>
        </div>

        {/* Add Entry Form */}
        {showAddForm && (
          <form onSubmit={handleSubmit} className="p-5 rounded-2xl bg-slate-950 border border-amber-500/30 space-y-4 animate-fade-in">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-2">
                <label className="block text-[11px] font-bold uppercase text-slate-300 mb-1">
                  {isPt ? 'Título do Pedido ou Milagre' : 'Título de la Petición o Milagro'}
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder={isPt ? 'Ex: Cura das dores de cabeça, Venda da casa...' : 'Ej: Sanación de dolores, Pago de hipoteca...'}
                  className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase text-slate-300 mb-1">
                  {isPt ? 'Categoria' : 'Categoría'}
                </label>
                <select
                  value={category}
                  onChange={e => setCategory(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-amber-500"
                >
                  <option value="financas">{isPt ? 'Finanças' : 'Finanzas'}</option>
                  <option value="saude">{isPt ? 'Saúde' : 'Salud'}</option>
                  <option value="familia">{isPt ? 'Família' : 'Familia'}</option>
                  <option value="protecao">{isPt ? 'Proteção' : 'Protección'}</option>
                  <option value="outro">{isPt ? 'Outro' : 'Otro'}</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold uppercase text-slate-300 mb-1">
                {isPt ? 'Detalhes ou Agradecimento' : 'Detalles o Agradecimiento'}
              </label>
              <textarea
                rows={2}
                required
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder={isPt ? 'Escreva como estava a situação e como você orou...' : 'Escribe cómo estaba la situación y cómo oraste...'}
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-3 py-1.5 rounded-lg text-xs text-slate-400 hover:text-white"
              >
                {isPt ? 'Cancelar' : 'Cancelar'}
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs"
              >
                {isPt ? 'Salvar no Diário' : 'Guardar en Diario'}
              </button>
            </div>
          </form>
        )}

        {/* Entry List */}
        {entries.length === 0 ? (
          <div className="text-center py-10 border border-dashed border-slate-800 rounded-2xl">
            <HeartHandshake className="w-10 h-10 text-slate-600 mx-auto mb-2" />
            <p className="text-sm text-slate-400 font-medium">
              {isPt ? 'Nenhuma entrada ainda no seu diário de graças.' : 'Aún no hay entradas en tu diario de gracias.'}
            </p>
            <p className="text-xs text-slate-500 mt-1">
              {isPt 
                ? 'Clique acima para registrar seu primeiro pedido ou milagre concedido!' 
                : '¡Haz clic arriba para anotar tu primera petición o milagro concedido!'}
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {entries.map(entry => (
              <div
                key={entry.id}
                className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
                  entry.answered
                    ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-200'
                    : 'bg-slate-950/70 border-slate-800 text-slate-200'
                }`}
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-800 text-amber-300">
                      {entry.category}
                    </span>
                    <span className="text-xs text-slate-500">{entry.date}</span>
                    {entry.answered && (
                      <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        {isPt ? 'Milagre Atendido' : 'Milagro Concedido'}
                      </span>
                    )}
                  </div>
                  <h4 className="font-serif-sacred font-bold text-base text-white">
                    {entry.title}
                  </h4>
                  <p className="text-xs text-slate-400 leading-relaxed whitespace-pre-line">
                    {entry.description}
                  </p>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                  <button
                    onClick={() => onToggleAnswered(entry.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                      entry.answered
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : 'bg-slate-800 text-slate-300 hover:text-white border border-slate-700'
                    }`}
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>
                      {entry.answered 
                        ? (isPt ? 'Atendido' : 'Concedido') 
                        : (isPt ? 'Marcar Atendido' : 'Marcar Concedido')}
                    </span>
                  </button>

                  <button
                    onClick={() => onDeleteEntry(entry.id)}
                    className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                    title="Excluir"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
