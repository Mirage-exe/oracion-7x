import React from 'react';
import { Language } from '../types';
import { 
  Calendar, 
  Flame, 
  Clock, 
  Sun, 
  Moon, 
  ShieldCheck, 
  CheckCircle2, 
  Award,
  Sparkles
} from 'lucide-react';

interface DailyTrackerProps {
  lang: Language;
  streakDays: number;
  completedDays: number[];
  onToggleDay: (day: number) => void;
  onResetStreak: () => void;
}

export const DailyTracker: React.FC<DailyTrackerProps> = ({
  lang,
  streakDays,
  completedDays,
  onToggleDay,
}) => {
  const isPt = lang === 'pt';

  const totalDays = 21;
  const daysArray = Array.from({ length: totalDays }, (_, i) => i + 1);

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in">
      {/* Header Banner */}
      <div className="relative rounded-3xl p-6 sm:p-8 bg-gradient-to-b from-slate-900 to-slate-950 border border-amber-500/30 overflow-hidden shadow-2xl text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold uppercase tracking-wider mb-3">
          <Calendar className="w-3.5 h-3.5 text-amber-400" />
          <span>{isPt ? 'Protocolo da Ordem Correta' : 'Protocolo del Orden Correcto'}</span>
        </div>

        <h2 className="font-serif-sacred text-2xl sm:text-3xl md:text-4xl font-bold text-amber-100 tracking-wide">
          {isPt ? 'Jornada dos 21 Dias de Milagres' : 'Jornada de 21 Días de Milagros'}
        </h2>

        <p className="mt-2 text-slate-300 text-sm max-w-xl mx-auto">
          {isPt
            ? '«Reze todos os dias, sem falhar nenhum. Como Marina que rezou 35 dias e foi curada, e Lourdes que no 3º dia viu suas dívidas começarem a sumir.»'
            : '«Reza todos los días, sin fallar uno solo. Como Marina que rezó 35 días y fue sanada, y Lourdes que al tercer día vio sus deudas desaparecer.»'}
        </p>

        {/* Current streak card */}
        <div className="mt-6 inline-flex items-center gap-4 px-6 py-3 rounded-2xl bg-slate-950/80 border border-amber-500/40 shadow-lg">
          <div className="flex items-center gap-2">
            <Flame className="w-6 h-6 text-amber-400 fill-amber-400 animate-bounce" />
            <span className="font-serif-sacred text-2xl font-bold text-amber-300">{streakDays}</span>
            <span className="text-xs text-slate-400 font-medium">{isPt ? 'dias consecutivos' : 'días consecutivos'}</span>
          </div>
          <div className="h-6 w-px bg-slate-800" />
          <div className="text-xs text-slate-300 font-medium">
            <span className="text-emerald-400 font-bold">{completedDays.length}</span> / {totalDays} {isPt ? 'concluídos' : 'completados'}
          </div>
        </div>
      </div>

      {/* Recommended Prayer Hours (From VSL stories) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-start gap-4">
          <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
            <Sun className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-serif-sacred font-bold text-slate-100 text-base">
              {isPt ? 'Oração do Alvorecer (Cedinho)' : 'Oración del Alba (Temprano)'}
            </h4>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              {isPt 
                ? 'Como fazia Lourdes na cozinha antes de trabalhar: coloca o áudio e reza com fé para abrir as portas do dia.'
                : 'Como hacía Lourdes en la cocina antes de trabajar: pon el audio y reza con fe para abrir las puertas del día.'}
            </p>
            <span className="inline-block mt-2 text-[11px] font-mono text-amber-400/90 font-semibold">
              {isPt ? 'Recomendado: 06:00 às 08:30' : 'Recomendado: 06:00 a 08:30'}
            </span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-start gap-4">
          <div className="p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400">
            <Moon className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-serif-sacred font-bold text-slate-100 text-base">
              {isPt ? 'Oração do Crepúsculo (Blindagem)' : 'Oración del Crepúsculo (Blindaje)'}
            </h4>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              {isPt
                ? 'Como fazia Carlos ao voltar para casa: selar com São Miguel para afastar pesadelos e energias pesadas.'
                : 'Como hacía Carlos al regresar a casa: sellar con San Miguel para disipar pesadillas y energías pesadas.'}
            </p>
            <span className="inline-block mt-2 text-[11px] font-mono text-blue-400/90 font-semibold">
              {isPt ? 'Recomendado: 19:00 às 22:30' : 'Recomendado: 19:00 a 22:30'}
            </span>
          </div>
        </div>
      </div>

      {/* 21-Day Interactive Grid */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800 shadow-xl">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="font-serif-sacred text-lg font-bold text-white">
              {isPt ? 'Calendário de Consagração dos 21 Dias' : 'Calendario de Consagración de 21 Días'}
            </h3>
            <p className="text-xs text-slate-400">
              {isPt 
                ? 'Clique no dia para marcar como orado com os 3 Arcanjos.' 
                : 'Haz clic en el día para marcarlo como orado con los 3 Arcángeles.'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-7 gap-3">
          {daysArray.map(day => {
            const isDone = completedDays.includes(day);
            return (
              <button
                key={day}
                onClick={() => onToggleDay(day)}
                className={`p-3 rounded-2xl border text-center transition-all duration-300 relative ${
                  isDone
                    ? 'bg-gradient-to-br from-amber-500/20 to-yellow-500/10 border-amber-500/50 text-amber-200 shadow-md scale-102'
                    : 'bg-slate-950/70 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                }`}
              >
                <span className="text-[10px] uppercase font-bold text-slate-500 block">
                  {isPt ? 'Dia' : 'Día'}
                </span>
                <span className="font-serif-sacred text-lg font-bold block mt-0.5">
                  {day}
                </span>
                {isDone ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 mx-auto mt-1" />
                ) : (
                  <div className="w-2 h-2 rounded-full bg-slate-800 mx-auto mt-2" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* The 3 Guarantees Section from VSL */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border border-amber-500/25">
        <div className="text-center mb-6">
          <Award className="w-6 h-6 text-amber-400 mx-auto mb-2" />
          <h4 className="font-serif-sacred text-lg sm:text-xl font-bold text-amber-200">
            {isPt ? 'As Três Garantias de Fé do Padre Juan Bautista' : 'Las Tres Garantías de Fe del Padre Juan Bautista'}
          </h4>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800">
            <span className="text-xs font-bold uppercase text-amber-400">
              {isPt ? 'Garantia 1' : 'Garantía 1'}
            </span>
            <div className="font-serif-sacred text-base font-bold text-slate-100 mt-1">
              24 Horas
            </div>
            <p className="text-xs text-slate-400 mt-1">
              {isPt 
                ? 'Sinal inequívoco de paz interior e alívio do peso no peito.'
                : 'Señal inequívoca de paz interior y desahogo en el corazón.'}
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800">
            <span className="text-xs font-bold uppercase text-amber-400">
              {isPt ? 'Garantia 2' : 'Garantía 2'}
            </span>
            <div className="font-serif-sacred text-base font-bold text-slate-100 mt-1">
              90 Días
            </div>
            <p className="text-xs text-slate-400 mt-1">
              {isPt 
                ? 'Transformação tangível em saúde, contas pagas ou casamento.'
                : 'Transformación tangible en salud, deudas saldadas o familia.'}
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800">
            <span className="text-xs font-bold uppercase text-amber-400">
              {isPt ? 'Garantia 3' : 'Garantía 3'}
            </span>
            <div className="font-serif-sacred text-base font-bold text-slate-100 mt-1">
              180 Días
            </div>
            <p className="text-xs text-slate-400 mt-1">
              {isPt 
                ? 'Multiplicação da provisão e proteção perpétua do lar.'
                : 'Multiplicación de la provisión y protección perpetua del hogar.'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
