import React, { useState } from 'react';
import { FAQ_DATA } from '../data/prayersData';
import { Language } from '../types';
import { HelpCircle, ChevronDown, ChevronUp } from 'lucide-react';

interface FaqSectionProps {
  lang: Language;
}

export const FaqSection: React.FC<FaqSectionProps> = ({ lang }) => {
  const isPt = lang === 'pt';
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggle = (idx: number) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-4 pt-6 border-t border-slate-800">
      <div className="flex items-center gap-2 mb-4">
        <HelpCircle className="w-5 h-5 text-amber-400" />
        <h3 className="font-serif-sacred text-xl font-bold text-slate-100">
          {isPt ? 'Perguntas Frequentes sobre o Método' : 'Preguntas Frecuentes sobre el Método'}
        </h3>
      </div>

      <div className="space-y-3">
        {FAQ_DATA.map((item, idx) => {
          const isOpen = openIndex === idx;
          return (
            <div
              key={idx}
              className="rounded-2xl border border-slate-800 bg-slate-900/60 overflow-hidden transition-colors"
            >
              <button
                onClick={() => toggle(idx)}
                className="w-full p-4 sm:p-5 text-left flex items-center justify-between gap-4 text-sm font-semibold text-slate-200 hover:text-amber-300"
              >
                <span>{isPt ? item.qPt : item.qEs}</span>
                {isOpen ? <ChevronUp className="w-4 h-4 text-amber-400 shrink-0" /> : <ChevronDown className="w-4 h-4 text-slate-500 shrink-0" />}
              </button>

              {isOpen && (
                <div className="px-4 sm:px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-400 leading-relaxed border-t border-slate-800/80">
                  {isPt ? item.aPt : item.aEs}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
