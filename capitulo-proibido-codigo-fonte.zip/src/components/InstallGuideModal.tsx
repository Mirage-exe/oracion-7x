import React, { useState } from 'react';
import { X, Smartphone, Share, PlusSquare, MoreVertical, Download, CheckCircle2, Sparkles } from 'lucide-react';
import { Language } from '../types';

interface InstallGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  installPrompt?: any;
  onTriggerInstall?: () => void;
}

export const InstallGuideModal: React.FC<InstallGuideModalProps> = ({
  isOpen,
  onClose,
  lang,
  installPrompt,
  onTriggerInstall
}) => {
  if (!isOpen) return null;
  const isPt = lang === 'pt';
  const [deviceTab, setDeviceTab] = useState<'iphone' | 'android'>('android');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg rounded-3xl p-6 sm:p-8 bg-slate-950 border-2 border-amber-500/40 shadow-2xl text-white max-h-[92vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white bg-slate-900 border border-slate-800"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center mb-6">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300 mb-3 shadow-lg shadow-amber-500/20">
            <Smartphone className="w-7 h-7" />
          </div>
          <h3 className="font-serif-sacred text-xl sm:text-2xl font-bold text-amber-100">
            {isPt ? 'Como Instalar no seu Celular' : 'Cómo Instalar en tu Celular'}
          </h3>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            {isPt
              ? 'Tenha o ícone sagrado na sua tela inicial para rezar todos os dias com apenas 1 toque!'
              : '¡Ten el icono sagrado en tu pantalla de inicio para rezar todos los días con solo 1 toque!'}
          </p>
        </div>

        {/* 1-Tap native install if available on Android */}
        {installPrompt && (
          <div className="mb-6 p-4 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-center animate-pulse">
            <button
              onClick={onTriggerInstall}
              className="w-full py-3.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm flex items-center justify-center gap-2 shadow-lg"
            >
              <Download className="w-5 h-5" />
              <span>{isPt ? 'INSTALAR AGORA NO MEU CELULAR' : 'INSTALAR AHORA EN MI CELULAR'}</span>
            </button>
          </div>
        )}

        {/* Device Switcher (iPhone vs Android) */}
        <div className="grid grid-cols-2 gap-2 p-1 rounded-2xl bg-slate-900 border border-slate-800 mb-6">
          <button
            onClick={() => setDeviceTab('android')}
            className={`py-2.5 px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all ${
              deviceTab === 'android'
                ? 'bg-amber-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>🤖 Android (Samsung, etc.)</span>
          </button>
          <button
            onClick={() => setDeviceTab('iphone')}
            className={`py-2.5 px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all ${
              deviceTab === 'iphone'
                ? 'bg-amber-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>🍏 iPhone (Apple)</span>
          </button>
        </div>

        {/* Step-by-Step for Android */}
        {deviceTab === 'android' && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-start gap-3.5">
              <div className="w-8 h-8 rounded-full bg-amber-500/20 border border-amber-500/30 flex items-center justify-center font-bold text-amber-300 shrink-0 text-sm">
                1
              </div>
              <div>
                <h4 className="font-bold text-slate-100 text-sm flex items-center gap-1.5">
                  <span>{isPt ? 'Toque nos 3 Pontinhos' : 'Toca los 3 Puntos'}</span>
                  <MoreVertical className="w-4 h-4 text-amber-400 inline" />
                </h4>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  {isPt
                    ? 'No topo direito do seu navegador Google Chrome, toque no botão com os três pontinhos verticais.'
                    : 'En la parte superior derecha de Google Chrome, toca el botón con tres puntos verticales.'}
                </p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-start gap-3.5">
              <div className="w-8 h-8 rounded-full bg-amber-500/20 border border-amber-500/30 flex items-center justify-center font-bold text-amber-300 shrink-0 text-sm">
                2
              </div>
              <div>
                <h4 className="font-bold text-slate-100 text-sm flex items-center gap-1.5">
                  <Download className="w-4 h-4 text-emerald-400" />
                  <span>{isPt ? 'Escolha "Instalar Aplicativo"' : 'Elige "Instalar Aplicación"'}</span>
                </h4>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  {isPt
                    ? 'No menu que abrir, toque na opção "Instalar aplicativo" (ou "Adicionar à tela inicial").'
                    : 'En el menú que aparece, toca en "Instalar aplicación" (o "Agregar a la pantalla principal").'}
                </p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-start gap-3.5">
              <div className="w-8 h-8 rounded-full bg-amber-500/20 border border-amber-500/30 flex items-center justify-center font-bold text-amber-300 shrink-0 text-sm">
                3
              </div>
              <div>
                <h4 className="font-bold text-slate-100 text-sm flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>{isPt ? 'Confirmar e Pronto!' : '¡Confirmar y Listo!'}</span>
                </h4>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  {isPt
                    ? 'Toque em "Instalar". O ícone dourado do Capítulo Proibido aparecerá na sua tela junto aos seus aplicativos como WhatsApp.'
                    : 'Toca en "Instalar". El icono dorado del Capítulo Prohibido aparecerá en tu pantalla junto a tus demás aplicaciones.'}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Step-by-Step for iPhone */}
        {deviceTab === 'iphone' && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-start gap-3.5">
              <div className="w-8 h-8 rounded-full bg-amber-500/20 border border-amber-500/30 flex items-center justify-center font-bold text-amber-300 shrink-0 text-sm">
                1
              </div>
              <div>
                <h4 className="font-bold text-slate-100 text-sm flex items-center gap-1.5">
                  <span>{isPt ? 'Toque em Compartilhar' : 'Toca en Compartir'}</span>
                  <Share className="w-4 h-4 text-amber-400 inline" />
                </h4>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  {isPt
                    ? 'Abra esta página no Safari. Na barra inferior do iPhone, toque no botão de Compartilhar (o ícone de quadrado com setinha para cima).'
                    : 'Abre esta página en Safari. En la barra inferior de tu iPhone, toca el botón Compartir (el cuadradito con flecha hacia arriba).'}
                </p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-start gap-3.5">
              <div className="w-8 h-8 rounded-full bg-amber-500/20 border border-amber-500/30 flex items-center justify-center font-bold text-amber-300 shrink-0 text-sm">
                2
              </div>
              <div>
                <h4 className="font-bold text-slate-100 text-sm flex items-center gap-1.5">
                  <PlusSquare className="w-4 h-4 text-emerald-400" />
                  <span>{isPt ? 'Selecione "Tela de Início"' : 'Selecciona "Pantalla de Inicio"'}</span>
                </h4>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  {isPt
                    ? 'Role para baixo nas opções e toque em "Adicionar à Tela de Início" (com o símbolo de mais ➕).'
                    : 'Desplaza hacia abajo y toca en "Agregar a inicio" (con el símbolo de más ➕).'}
                </p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-start gap-3.5">
              <div className="w-8 h-8 rounded-full bg-amber-500/20 border border-amber-500/30 flex items-center justify-center font-bold text-amber-300 shrink-0 text-sm">
                3
              </div>
              <div>
                <h4 className="font-bold text-slate-100 text-sm flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>{isPt ? 'Toque em "Adicionar"' : 'Toca en "Agregar"'}</span>
                </h4>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  {isPt
                    ? 'No canto superior direito, toque em "Adicionar". Pronto! O aplicativo sagrado abrirá direto da sua tela inicial.'
                    : 'En la esquina superior derecha toca "Agregar". ¡Listo! El aplicativo sagrado abrirá directo desde tu pantalla de inicio.'}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Bottom understood button */}
        <div className="mt-6 pt-4 border-t border-slate-800">
          <button
            onClick={onClose}
            className="w-full py-3.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold text-sm transition-all"
          >
            {isPt ? 'Entendi, fechar instruções' : 'Entendido, cerrar instrucciones'}
          </button>
        </div>
      </div>
    </div>
  );
};
