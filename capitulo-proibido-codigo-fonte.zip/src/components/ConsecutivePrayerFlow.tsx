import React, { useState, useEffect } from 'react';
import { PRAYERS_DATA } from '../data/prayersData';
import { Language } from '../types';
import { sacredAudio, speechNarrator } from '../utils/audioSystem';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  ChevronRight, 
  CheckCircle2, 
  Sparkles, 
  Feather, 
  Wind,
  Bell,
  ZoomIn,
  ZoomOut
} from 'lucide-react';

interface ConsecutivePrayerFlowProps {
  lang: Language;
  onCompleteSession: () => void;
  isTodayDone: boolean;
}

export const ConsecutivePrayerFlow: React.FC<ConsecutivePrayerFlowProps> = ({
  lang,
  onCompleteSession,
}) => {
  const isPt = lang === 'pt';
  const [currentStepIndex, setCurrentStepIndex] = useState(0); // 0: Rafael, 1: Gabriel, 2: Miguel
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [activeStanzaIndex, setActiveStanzaIndex] = useState<number | null>(null);
  const [isBreathingMode, setIsBreathingMode] = useState(false);
  const [breathPhase, setBreathPhase] = useState<'inhale' | 'hold' | 'exhale'>('inhale');
  const [completedSteps, setCompletedSteps] = useState<boolean[]>([false, false, false]);
  const [isSessionFinished, setIsSessionFinished] = useState(false);
  // Senior-friendly text scaling
  const [fontSizeLevel, setFontSizeLevel] = useState<'normal' | 'large' | 'extralarge'>('large');

  const currentPrayer = PRAYERS_DATA[currentStepIndex];

  useEffect(() => {
    speechNarrator.stop();
    setIsSpeaking(false);
    setActiveStanzaIndex(null);
  }, [currentStepIndex]);

  useEffect(() => {
    if (!isBreathingMode) return;
    const interval = setInterval(() => {
      setBreathPhase(prev => {
        if (prev === 'inhale') return 'hold';
        if (prev === 'hold') return 'exhale';
        return 'inhale';
      });
    }, 4000);
    return () => clearInterval(interval);
  }, [isBreathingMode]);

  const handleStartNarration = () => {
    sacredAudio.playCathedralChime();
    sacredAudio.playSacredFrequency(currentPrayer.frequencyHz, 0.07);

    const stanzas = currentPrayer.stanzas[lang];
    const fullText = stanzas.join('. ');

    setIsSpeaking(true);
    setActiveStanzaIndex(0);

    speechNarrator.speak({
      text: fullText,
      lang,
      onStart: () => setIsSpeaking(true),
      onEnd: () => {
        setIsSpeaking(false);
        setActiveStanzaIndex(null);
        setCompletedSteps(prev => {
          const updated = [...prev];
          updated[currentStepIndex] = true;
          return updated;
        });
      }
    });
  };

  const handlePauseNarration = () => {
    speechNarrator.pause();
    setIsSpeaking(false);
  };

  const handleStopNarration = () => {
    speechNarrator.stop();
    sacredAudio.stopSacredFrequency();
    setIsSpeaking(false);
    setActiveStanzaIndex(null);
  };

  const handleNextStep = () => {
    handleStopNarration();
    sacredAudio.playCathedralChime();
    setCompletedSteps(prev => {
      const updated = [...prev];
      updated[currentStepIndex] = true;
      return updated;
    });

    if (currentStepIndex < 2) {
      setCurrentStepIndex(prev => prev + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      setIsSessionFinished(true);
      onCompleteSession();
    }
  };

  const handleJumpToStep = (index: number) => {
    handleStopNarration();
    setCurrentStepIndex(index);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const resetSession = () => {
    handleStopNarration();
    setCurrentStepIndex(0);
    setCompletedSteps([false, false, false]);
    setIsSessionFinished(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const getTextClass = () => {
    if (fontSizeLevel === 'extralarge') return 'text-xl sm:text-2xl leading-relaxed';
    if (fontSizeLevel === 'large') return 'text-lg sm:text-xl leading-relaxed';
    return 'text-base sm:text-lg leading-relaxed';
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-12">
      {/* Sacred Order Instruction for Seniors */}
      <div className="rounded-2xl p-4 sm:p-6 bg-gradient-to-b from-slate-900 to-slate-950 border border-amber-500/30 text-center shadow-lg">
        <span className="inline-block px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold uppercase mb-2">
          {isPt ? 'A Chave dos Milagres' : 'La Llave de los Milagros'}
        </span>
        <h2 className="font-serif-sacred text-xl sm:text-2xl md:text-3xl font-bold text-amber-100">
          {isPt ? 'Ordem Sagrada de Oração' : 'Orden Sagrado de Oración'}
        </h2>
        <p className="mt-1 text-slate-300 text-xs sm:text-sm max-w-xl mx-auto">
          {isPt
            ? '1º Rafael (Cura) ➔ 2º Gabriel (Abertura de Portas) ➔ 3º Miguel (Proteção e Selamento)'
            : '1º Rafael (Sanación) ➔ 2º Gabriel (Apertura de Puertas) ➔ 3º Miguel (Protección y Sellado)'}
        </p>

        {/* Big Touch Steps */}
        <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-slate-800">
          {PRAYERS_DATA.map((prayer, idx) => {
            const isCurrent = currentStepIndex === idx;
            const isDone = completedSteps[idx];
            return (
              <button
                key={prayer.id}
                onClick={() => handleJumpToStep(idx)}
                className={`py-3 px-2 rounded-xl border text-center transition-all ${
                  isCurrent
                    ? 'border-amber-400 bg-amber-500/20 text-amber-200 shadow-md scale-102 font-bold'
                    : isDone
                    ? 'border-emerald-500/40 bg-emerald-950/20 text-emerald-300'
                    : 'border-slate-800 bg-slate-950/60 text-slate-400'
                }`}
              >
                <div className="text-[10px] uppercase font-bold text-slate-400">
                  {idx + 1}º {isPt ? 'Passo' : 'Paso'}
                </div>
                <div className="font-serif-sacred text-xs sm:text-sm font-bold truncate mt-0.5">
                  {idx === 0 ? 'Rafael' : idx === 1 ? 'Gabriel' : 'Miguel'}
                </div>
                {isDone ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mx-auto mt-1" />
                ) : isCurrent ? (
                  <span className="inline-block w-2 h-2 rounded-full bg-amber-400 animate-ping mt-1" />
                ) : null}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Prayer Card */}
      {!isSessionFinished ? (
        <div className={`rounded-3xl p-5 sm:p-8 border transition-all bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950 ${currentPrayer.colorTheme.border} ${currentPrayer.colorTheme.glow}`}>
          {/* Header of Active Archangel */}
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div>
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${currentPrayer.colorTheme.bgBadge}`}>
                {isPt ? `Oração ${currentPrayer.order} de 3` : `Oración ${currentPrayer.order} de 3`}
              </span>
              <h3 className="font-serif-sacred text-xl sm:text-2xl font-bold text-white mt-1">
                {isPt ? currentPrayer.namePt : currentPrayer.name}
              </h3>
              <p className="text-xs text-amber-200 font-medium">
                {isPt ? currentPrayer.titlePt : currentPrayer.title}
              </p>
            </div>

            {/* Font size control for elderly users */}
            <div className="flex items-center gap-1 bg-slate-950 px-2 py-1 rounded-xl border border-slate-800">
              <button
                onClick={() => setFontSizeLevel('normal')}
                title="Texto normal"
                className={`p-1.5 rounded text-xs font-bold ${fontSizeLevel === 'normal' ? 'bg-amber-500 text-slate-950' : 'text-slate-400'}`}
              >
                A
              </button>
              <button
                onClick={() => setFontSizeLevel('large')}
                title="Texto grande"
                className={`p-1.5 rounded text-sm font-bold ${fontSizeLevel === 'large' ? 'bg-amber-500 text-slate-950' : 'text-slate-400'}`}
              >
                A+
              </button>
              <button
                onClick={() => setFontSizeLevel('extralarge')}
                title="Texto muito grande"
                className={`p-1.5 rounded text-base font-bold ${fontSizeLevel === 'extralarge' ? 'bg-amber-500 text-slate-950' : 'text-slate-400'}`}
              >
                A++
              </button>
            </div>
          </div>

          {/* VSL Quote Reminder */}
          <div className="my-4 p-3.5 rounded-xl bg-amber-950/25 border border-amber-500/20 text-amber-200 text-xs sm:text-sm italic flex items-start gap-2.5">
            <Feather className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <span>«{isPt ? currentPrayer.quoteVslPt : currentPrayer.quoteVsl}»</span>
          </div>

          {/* Calming Breath Sanctuary (Optional) */}
          <div className="mb-4">
            <button
              onClick={() => setIsBreathingMode(!isBreathingMode)}
              className="text-xs font-semibold text-slate-400 hover:text-amber-300 flex items-center gap-1.5 transition-colors"
            >
              <Wind className="w-4 h-4 text-cyan-400" />
              <span>
                {isBreathingMode 
                  ? (isPt ? 'Fechar Respiração' : 'Cerrar Respiración')
                  : (isPt ? 'Respiração de Paz (Acalmar a Mente)' : 'Respiración de Paz (Serenar la Mente)')}
              </span>
            </button>

            {isBreathingMode && (
              <div className="mt-2 p-3 rounded-xl bg-cyan-950/30 border border-cyan-500/30 text-center animate-fade-in">
                <p className="text-xs text-cyan-300 font-bold mb-1">
                  {breathPhase === 'inhale' 
                    ? (isPt ? 'Inspire profundamente a luz...' : 'Inhala profundamente la luz...')
                    : breathPhase === 'hold'
                    ? (isPt ? 'Sustente e sinta a presença de Deus...' : 'Sostén y siente la presencia de Dios...')
                    : (isPt ? 'Expire suavemente e solte as dores...' : 'Exhala suavemente y suelta los dolores...')}
                </p>
                <div className="w-10 h-10 mx-auto rounded-full bg-cyan-500/20 border-2 border-cyan-400 flex items-center justify-center">
                  <Wind className="w-5 h-5 text-cyan-300 animate-pulse" />
                </div>
              </div>
            )}
          </div>

          {/* Big Prayer Stanzas */}
          <div className="space-y-3.5 my-4">
            {currentPrayer.stanzas[lang].map((stanza, sIdx) => {
              const isHighlight = activeStanzaIndex === sIdx;
              return (
                <div
                  key={sIdx}
                  className={`p-4 rounded-2xl transition-all border ${
                    isHighlight
                      ? 'bg-amber-500/20 border-amber-400/60 shadow-md'
                      : 'bg-slate-950/70 border-slate-800'
                  }`}
                >
                  <p className={`font-scripture text-slate-100 ${getTextClass()}`}>
                    {stanza}
                  </p>
                </div>
              );
            })}
          </div>

          {/* Big Controls Bar */}
          <div className="pt-4 border-t border-slate-800 flex flex-col gap-3">
            {/* Audio narrator button */}
            {!isSpeaking ? (
              <button
                onClick={handleStartNarration}
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-bold text-base flex items-center justify-center gap-2 shadow-xl shadow-amber-500/20 transition-all active:scale-98"
              >
                <Play className="w-5 h-5 fill-slate-950" />
                <span>{isPt ? 'OUVIR ORAÇÃO COM VOZ SAGRADA' : 'ESCUCHAR CON VOZ SAGRADA'}</span>
              </button>
            ) : (
              <div className="flex gap-2">
                <button
                  onClick={handlePauseNarration}
                  className="flex-1 py-3.5 rounded-2xl bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold text-sm flex items-center justify-center gap-2"
                >
                  <Pause className="w-5 h-5" />
                  <span>{isPt ? 'Pausar Áudio' : 'Pausar Audio'}</span>
                </button>
                <button
                  onClick={handleStopNarration}
                  className="px-4 py-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
                >
                  <RotateCcw className="w-5 h-5" />
                </button>
              </div>
            )}

            {/* Advance Button */}
            <button
              onClick={handleNextStep}
              className={`w-full py-4 rounded-2xl font-bold text-base flex items-center justify-center gap-2 transition-all shadow-lg active:scale-98 ${
                currentStepIndex === 2
                  ? 'bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-700 text-white'
                  : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700'
              }`}
            >
              <span>
                {currentStepIndex === 2
                  ? (isPt ? 'CONCLUIR AS 3 ORAÇÕES SAGRADAS' : 'CONCLUIR LAS 3 ORACIONES SAGRADAS')
                  : (isPt ? `AVANÇAR PARA ${PRAYERS_DATA[currentStepIndex + 1].namePt.toUpperCase()}` : `AVANZAR A ${PRAYERS_DATA[currentStepIndex + 1].name.toUpperCase()}`)}
              </span>
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      ) : (
        /* Celebration Completed Card */
        <div className="rounded-3xl p-6 sm:p-10 text-center bg-gradient-to-b from-amber-950/40 via-slate-900 to-slate-950 border border-amber-500/40 shadow-2xl animate-fade-in">
          <div className="w-16 h-16 mx-auto rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 flex items-center justify-center shadow-lg shadow-amber-500/30 mb-4">
            <CheckCircle2 className="w-9 h-9 text-slate-950" />
          </div>

          <h3 className="font-serif-sacred text-2xl font-bold text-amber-200">
            {isPt 
              ? 'Tríplice Aliança Celestial Ativada!' 
              : '¡Triple Alianza Celestial Activada!'}
          </h3>

          <p className="mt-2 text-slate-300 text-sm max-w-md mx-auto leading-relaxed">
            {isPt
              ? 'Você orou na ordem sagrada revelada pelo Padre Juan Bautista. Rafael curou, Gabriel abriu as portas e Miguel colocou o escudo de fogo protetor.'
              : 'Has rezado en el orden sagrado revelado por el Padre Juan Bautista. Rafael curó, Gabriel abrió las puertas y Miguel colocó el escudo de fuego protector.'}
          </p>

          <div className="mt-6">
            <button
              onClick={resetSession}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold text-base shadow-lg"
            >
              {isPt ? 'REPETIR ORAÇÃO DO DIA' : 'REPETIR ORACIÓN DEL DÍA'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
