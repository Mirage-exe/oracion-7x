import React from 'react';
import { X, Download, Archive, CheckCircle2, Globe, FileCode2, Sparkles } from 'lucide-react';
import { Language } from '../types';

interface DownloadZipModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const DownloadZipModal: React.FC<DownloadZipModalProps> = ({
  isOpen,
  onClose,
  lang,
}) => {
  if (!isOpen) return null;
  const isPt = lang === 'pt';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg rounded-3xl p-6 sm:p-8 bg-slate-950 border-2 border-amber-500/40 shadow-2xl text-white">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white bg-slate-900 border border-slate-800"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center mb-6">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300 mb-3 shadow-lg shadow-amber-500/20">
            <Archive className="w-7 h-7" />
          </div>
          <h3 className="font-serif-sacred text-xl sm:text-2xl font-bold text-amber-100">
            {isPt ? 'Baixar Arquivos ZIP' : 'Descargar Archivos ZIP'}
          </h3>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            {isPt
              ? 'Escolha a opção desejada para baixar e hospedar em qualquer site ou servidor.'
              : 'Elige la opción deseada para descargar y alojar en tu propio servidor.'}
          </p>
        </div>

        {/* Download Options */}
        <div className="space-y-4">
          {/* Option 1: Ready to host dist */}
          <div className="p-5 rounded-2xl bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-950 border border-amber-500/40 shadow-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-amber-500 text-slate-950">
                {isPt ? 'Recomendado' : 'Recomendado'}
              </span>
              <span className="text-xs text-slate-400 font-mono">~173 KB</span>
            </div>
            <h4 className="font-serif-sacred font-bold text-base text-amber-100 flex items-center gap-2">
              <Globe className="w-4 h-4 text-amber-400" />
              <span>{isPt ? 'Site Pronto (Pasta Dist Compilada)' : 'Sitio Listo (Carpeta Dist Compilada)'}</span>
            </h4>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              {isPt
                ? 'Ideal para subir direto no cPanel, Hostinger, Locaweb, Vercel ou Netlify. Não precisa instalar nada, é só descompactar na pasta do site!'
                : 'Ideal para subir directo a cPanel, Hostinger o cualquier hosting web. No requiere Node.js, solo descomprime y listo.'}
            </p>
            <a
              href="/capitulo-proibido-site-pronto.zip"
              download="capitulo-proibido-site-pronto.zip"
              className="mt-4 w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg transition-all"
            >
              <Download className="w-4 h-4 fill-slate-950" />
              <span>{isPt ? 'BAIXAR SITE PRONTO (.ZIP)' : 'DESCARGAR SITIO LISTO (.ZIP)'}</span>
            </a>
          </div>

          {/* Option 2: Full Source Code */}
          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                {isPt ? 'Desenvolvedor' : 'Desarrollador'}
              </span>
              <span className="text-xs text-slate-400 font-mono">~82 KB</span>
            </div>
            <h4 className="font-serif-sacred font-bold text-base text-slate-200 flex items-center gap-2">
              <FileCode2 className="w-4 h-4 text-blue-400" />
              <span>{isPt ? 'Código Fonte Completo (React + Vite)' : 'Código Fuente Completo (React + Vite)'}</span>
            </h4>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              {isPt
                ? 'Para programadores que queiram editar o código, adicionar novos componentes ou subir no GitHub.'
                : 'Para programadores que deseen editar el código o subirlo a GitHub.'}
            </p>
            <a
              href="/capitulo-proibido-codigo-fonte.zip"
              download="capitulo-proibido-codigo-fonte.zip"
              className="mt-4 w-full py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 border border-slate-700 transition-all"
            >
              <Download className="w-4 h-4" />
              <span>{isPt ? 'BAIXAR CÓDIGO FONTE (.ZIP)' : 'DESCARGAR CÓDIGO FUENTE (.ZIP)'}</span>
            </a>
          </div>
        </div>

        {/* Close Button */}
        <div className="mt-6 pt-4 border-t border-slate-800">
          <button
            onClick={onClose}
            className="w-full py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs transition-all"
          >
            {isPt ? 'Fechar' : 'Cerrar'}
          </button>
        </div>
      </div>
    </div>
  );
};
